<?php
  require_once('includes/load.php');
  // Checking what level user has permission to view this page
  page_require_level(2);

  // Get the supplier ID from the URL
  $supplier_id = (int)$_GET['id'];
  
  // Proceed only if supplier ID exists
  if ($supplier_id) {
    // Manually construct the DELETE query
    $query = "DELETE FROM suppliers WHERE supplier_id='{$supplier_id}' LIMIT 1";
    $result = $db->query($query);

    // Check if the query was successful
    if ($result && $db->affected_rows() === 1) {
      $session->msg("s", "Supplier deleted.");
      redirect('suppliers.php');
    } else {
      $session->msg("d", "Failed to delete supplier.");
      redirect('suppliers.php');
    }
  } else {
    $session->msg("d", "Missing supplier id.");
    redirect('suppliers.php');
  }
?>