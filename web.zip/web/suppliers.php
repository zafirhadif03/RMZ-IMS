<?php
  $page_title = 'All Suppliers';
  require_once('includes/load.php');
  page_require_level(2);

  // Define the number of results per page
  $results_per_page = 7;

  // Get the current page number from the URL, if none set, default to 1
  $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
  $page = max($page, 1); // Ensure the page number is at least 1

  // Calculate the starting record for the current page
  $start_from = ($page - 1) * $results_per_page;

  // Fetch the limited number of suppliers for the current page
  $suppliers = find_suppliers_with_pagination($start_from, $results_per_page);

  // Fetch total number of suppliers for pagination
  $total_suppliers = count_all('suppliers');
  $total_pages = ceil($total_suppliers / $results_per_page);
?>

<?php include_once('layouts/header.php'); ?>
<div class="row">
   <div class="col-md-12">
    <br><br>
     <?php echo display_msg($msg); ?>
   </div>

   <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
      <span class="glyphicon glyphicon-user"></span>
      <strong><span>All Suppliers</span></strong>
       
      <div class="pull-right">
         <a href="add_supplier.php" class="btn btn-primary">Add New</a>
       </div>
      </div>
      <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th> Supplier Name </th>
              <th class="text-center" style="width: 15%;"> Email </th>
              <th class="text-center" style="width: 10%;"> Phone Number </th>
              <th class="text-center" style="width: 20%;"> Address </th>
              <th class="text-center" style="width: 100px;"> Actions </th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($suppliers as $supplier): ?>
            <tr>
                <td class="text-center"><?php echo count_id();?></td>
                <td> <?php echo remove_junk($supplier['name']); ?></td>
                <td class="text-center"> <?php echo remove_junk($supplier['email']); ?></td>
                <td class="text-center"> <?php echo remove_junk($supplier['phone']); ?></td>
                <td> <?php echo remove_junk($supplier['address']); ?></td>
                <td class="text-center">
                <div class="btn-group">
            <a href="edit_supplier.php?id=<?php echo (int)$supplier['supplier_id']; ?>" class="btn btn-info btn-xs" title="Edit" data-toggle="tooltip">
                <span class="glyphicon glyphicon-edit"></span>
            </a>
            <a href="delete_supplier.php?id=<?php echo (int)$supplier['supplier_id']; ?>" class="btn btn-danger btn-xs" title="Delete" data-toggle="tooltip">
                <span class="glyphicon glyphicon-trash"></span>
            </a>
            </div>
        </tr>
        <?php endforeach; ?>
          </tbody>
        </table>

       <!-- Pagination controls -->
<nav aria-label="Page navigation">
  <ul class="pagination">
    <?php if ($page > 1): ?>
      <li>
        <a href="suppliers.php?page=<?php echo $page - 1; ?>" aria-label="Previous">
          <span aria-hidden="true">&laquo;</span>
        </a>
      </li>
    <?php endif; ?>
    
    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
      <li class="<?php echo ($i == $page) ? 'active' : ''; ?>">
        <a href="suppliers.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
      </li>
    <?php endfor; ?>
    
    <?php if ($page < $total_pages): ?>
      <li>
        <a href="suppliers.php?page=<?php echo $page + 1; ?>" aria-label="Next">
          <span aria-hidden="true">&raquo;</span>
        </a>
      </li>
    <?php endif; ?>
  </ul>
</nav>

      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>

<?php
// Add this function in your includes/functions.php
function find_suppliers_with_pagination($start_from, $results_per_page) {
  global $db;
  $sql  = "SELECT * FROM suppliers ";
  $sql .= "LIMIT {$start_from}, {$results_per_page}";
  return find_by_sql($sql);
}
