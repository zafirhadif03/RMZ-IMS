<?php
$page_title = 'FAQ';
require_once('includes/load.php');
?>

<?php include_once('layouts/header.php'); ?>

<div class="faq-container">
    <div class="faq-header">
        <h1>Frequently Asked Questions</h1>
        <p>Find answers to commonly asked questions below.</p>
    </div>

    <div class="faq-content">
        <!-- General Questions -->
        <div class="faq-category">
            <h2>General Questions</h2>
            <!-- FAQ 1 -->
            <div class="faq-item">
                <button class="faq-question">
                    What is RMZ IMS?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>RMZ IMS is an inventory management system designed to record stock, manage inventory, track usage, and generate reports for efficient business operations.</p>
                </div>
            </div>

            <!-- FAQ 2 -->
            <div class="faq-item">
                <button class="faq-question">
                    Who can use RMZ IMS?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>RMZ IMS is designed for Super Admins and Admins, offering varying levels of control based on user roles.</p>
                </div>
            </div>

            <!-- FAQ 3 -->
            <div class="faq-item">
                <button class="faq-question">
                    What are the primary features of RMZ IMS?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Key features include user management, product tracking, raw material usage, sales reporting, and the ability to convert raw materials into finished products.</p>
                </div>
            </div>

            <!-- FAQ 4 -->
            <div class="faq-item">
                <button class="faq-question">
                    Does the system support multi-user roles?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Yes, Super Admins and Admins have unique permissions for managing users, inventory, and reports.</p>
                </div>
            </div>

            <!-- FAQ 5 -->
            <div class="faq-item">
                <button class="faq-question">
                    What industries is RMZ IMS suitable for?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>It is ideal for businesses relying on stock and raw material management, like manufacturing, food processing, or retail.</p>
                </div>
            </div>
        </div>

        <!-- Technical Questions -->
        <div class="faq-category">
            <h2>Technical Questions</h2>
            <!-- FAQ 6 -->
            <div class="faq-item">
                <button class="faq-question">
                    What technologies were used to develop RMZ IMS?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>RMZ IMS uses PHP, MySQL for the backend, and Bootstrap for responsive interface design.</p>
                </div>
            </div>

            <!-- FAQ 7 -->
            <div class="faq-item">
                <button class="faq-question">
                    Can the system generate automated reports?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Yes, it includes features for daily, monthly, and raw material usage reports, downloadable in PDF format.</p>
                </div>
            </div>

            <!-- FAQ 8 -->
            <div class="faq-item">
                <button class="faq-question">
                    How does the recipe card function work?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Recipe cards allow users to define and track the raw materials used to produce finished products while updating inventory automatically.</p>
                </div>
            </div>

            <!-- FAQ 9 -->
            <div class="faq-item">
                <button class="faq-question">
                    Is RMZ IMS scalable?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>The system architecture supports the addition of new features, users, and products without performance degradation.</p>
                </div>
            </div>
        </div>

        <!-- Operational Questions -->
        <div class="faq-category">
            <h2>Operational Questions</h2>
            <!-- FAQ 10 -->
            <div class="faq-item">
                <button class="faq-question">
                    Can RMZ IMS alert for low stock levels?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Yes, it has low stock alerts to notify users about materials that need replenishment.</p>
                </div>
            </div>

            <!-- FAQ 11 -->
            <div class="faq-item">
                <button class="faq-question">
                    How is data security managed in RMZ IMS?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>User credentials are securely encrypted, and access is role-restricted to ensure sensitive data is protected.</p>
                </div>
            </div>

            <!-- FAQ 12 -->
            <div class="faq-item">
                <button class="faq-question">
                    Does the system support multiple units of measurement?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Yes, RMZ IMS allows users to track inventory in various units such as KG, G, etc.</p>
                </div>
            </div>
        </div>

        <!-- Usability Questions -->
        <div class="faq-category">
            <h2>Usability Questions</h2>
            <!-- FAQ 13 -->
            <div class="faq-item">
                <button class="faq-question">
                    Is the interface user-friendly?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Yes, RMZ IMS features a straightforward design to cater to users with varying levels of tech proficiency.</p>
                </div>
            </div>

            <!-- FAQ 14 -->
            <div class="faq-item">
                <button class="faq-question">
                    Can users update or modify their profiles?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>Yes, users can update their names, usernames, and passwords through the user settings.</p>
                </div>
            </div>

            <!-- FAQ 15 -->
            <div class="faq-item">
                <button class="faq-question">
                    How responsive is the system?
                    <span class="icon">+</span>
                </button>
                <div class="faq-answer">
                    <p>RMZ IMS is optimized for high performance, even with large volumes of inventory data.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const faqItems = document.querySelectorAll('.faq-item');
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                item.classList.toggle('active');
            });
        });
    });
</script>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f7f7f7;
        margin: 0;
        padding: 0;
    }

    .faq-container {
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .faq-header {
        text-align: center;
        margin-bottom: 30px;
    }

    .faq-header h1 {
        font-size: 4rem;
        margin-bottom: 10px;
    }

    .faq-header p {
        color: #555;
        font-size: 1.5rem; /* Updated size */
        line-height: 1.8; /* Optional: Improves readability */
    }

    .faq-content {
        border-top: 1px solid #e5e5e5;
    }

    .faq-item {
        border-bottom: 1px solid #e5e5e5;
        padding: 15px 0;
    }

    .faq-question {
        width: 100%;
        background: none;
        border: none;
        font-size: 1.8rem;
        font-weight: bold;
        text-align: left;
        padding: 0;
        margin: 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        color: #333;
    }

    .faq-question:hover {
        color: #0071e3;
    }

    .faq-answer {
        display: none;
        margin-top: 10px;
        font-size: 1.5rem;
        color: #555;
        line-height: 1.6;
    }

    .icon {
        font-size: 2rem;
        color: #555;
        transition: transform 0.2s ease;
    }

    .faq-item.active .icon {
        transform: rotate(45deg);
    }

    .faq-item.active .faq-answer {
        display: block;
    }
</style>

<?php include_once('layouts/footer.php'); ?>
