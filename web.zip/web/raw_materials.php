<?php
$page_title = 'Raw Materials';
require_once('includes/load.php');
// Check user permission level (adjust if necessary)
page_require_level(2);

// Set the number of records per page
$records_per_page = 5;

// Get the current page number from the query parameter
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = $page > 0 ? $page : 1; // Ensure page number is at least 1

// Calculate the offset for the SQL query
$offset = ($page - 1) * $records_per_page;

// Fetch the raw materials with pagination
$query = "SELECT raw_materials.*, suppliers.name AS supplier_name, suppliers.email AS supplier_email, ";
$query .= "suppliers.phone AS supplier_phone, suppliers.address AS supplier_address ";
$query .= "FROM raw_materials ";
$query .= "LEFT JOIN suppliers ON raw_materials.supplier_id = suppliers.supplier_id ";
$query .= "LIMIT {$records_per_page} OFFSET {$offset}";

$raw_materials = find_by_sql($query);

// Fetch the total number of raw materials for pagination
$total_query = "SELECT COUNT(*) AS total FROM raw_materials";
$total_result = find_by_sql($total_query);
$total_records = $total_result[0]['total'];
$total_pages = ceil($total_records / $records_per_page);
?>

<?php include_once('layouts/header.php'); ?>
<div class="row">
    <div class="col-md-12">
        <br><br>
        <?php echo display_msg($msg); ?>
    </div>

    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading clearfix">
                <span class="glyphicon glyphicon-th-list"></span>
                <span>Raw Materials</span>

                <div class="pull-right">
                    <a href="add_raw_material.php" class="btn btn-primary">Add New</a>
                </div>
            </div>
            <div class="panel-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">#</th>
                            <th> Material Name </th>
                            <th class="text-center" style="width: 15%;"> Unit </th>
                            <th class="text-center" style="width: 15%;"> Quantity </th>
                            <th class="text-center" style="width: 15%;"> Volume </th>
                            <th class="text-center" style="width: 15%;"> Date Added </th>
                            <th class="text-center" style="width: 15%;"> Supplier Info </th>
                            <th class="text-center" style="width: 100px;"> Actions </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($raw_materials as $index => $material): ?>
                            <tr>
                                <td class="text-center"><?php echo $offset + $index + 1; ?></td>
                                <td><?php echo remove_junk($material['name']); ?></td>
                                <td class="text-center"><?php echo remove_junk($material['unit']); ?></td>
                                <td class="text-center"><?php echo remove_junk($material['quantity']); ?></td>
                                <td class="text-center">
                                    <?php if ($material['quantity'] <= $material['low_stock_threshold']): ?>
                                        <span class="label label-danger">Low Stock</span>
                                    <?php else: ?>
                                        <span class="label label-success">Sufficient</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo remove_junk($material['created_at']); ?></td>
                                <td class="text-center">
                                    <!-- Mini-Supplier Info Panel -->
                                    <div class="panel panel-info">
                                        <div class="panel-heading">
                                            <strong><?php echo remove_junk($material['supplier_name']); ?></strong>
                                        </div>
                                        <div class="panel-body">
                                            <p>Email: <?php echo remove_junk($material['supplier_email']); ?></p>
                                            <p>Phone: <?php echo remove_junk($material['supplier_phone']); ?></p>
                                            <p>Address: <?php echo remove_junk($material['supplier_address']); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <a href="edit_raw_material.php?id=<?php echo (int)$material['id']; ?>" class="btn btn-info btn-xs" title="Edit" data-toggle="tooltip">
                                            <span class="glyphicon glyphicon-edit"></span>
                                        </a>
                                        <a href="delete_raw_material.php?id=<?php echo (int)$material['id']; ?>" class="btn btn-danger btn-xs" title="Delete" data-toggle="tooltip">
                                            <span class="glyphicon glyphicon-trash"></span>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <!-- Pagination Links -->
                <nav>
                    <ul class="pagination">
                        <?php if ($page > 1): ?>
                            <li><a href="raw_materials.php?page=<?php echo $page - 1; ?>">&laquo; Prev</a></li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="<?php echo $i === $page ? 'active' : ''; ?>">
                                <a href="raw_materials.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <li><a href="raw_materials.php?page=<?php echo $page + 1; ?>">Next &raquo;</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php include_once('layouts/footer.php'); ?>
