<?php
  require_once('includes/load.php');
  // Check user permission level
  page_require_level(2);

  // Get the raw material ID from the URL
  $material_id = (int)$_GET['id'];
  
  if ($material_id) {
    // Delete raw material by ID
    $delete_id = delete_by_id('raw_materials', $material_id);
    
    if ($delete_id) {
      $session->msg("s", "Raw material deleted successfully.");
      redirect('raw_materials.php');
    } else {
      $session->msg("d", "Failed to delete raw material.");
      redirect('raw_materials.php');
    }
  } else {
    $session->msg("d", "Missing raw material ID.");
    redirect('raw_materials.php');
  }
?>
