<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>


   

  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Manage Products</a> </li>
       <li><a href="add_product.php">Add Products</a> </li>
       <li><a href="media.php">Media Files</a> </li>
   </ul>
  </li>

  <li>
    <a href="convert_to_product.php" >
      <i class="glyphicon glyphicon-retweet"></i>
      <span>Convert to Product</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-book"></i>
      <span>Raw Materials</span>
    </a>
  <ul class="nav submenu">
       <li><a href="raw_materials.php">Manage Raw Materials</a> </li>
       <li><a href="add_raw_material.php">Add Raw Materials</a> </li>
   </ul>
  </li>

  <li>
    <a href="raw_materials_report.php" >
      <i class="glyphicon glyphicon-phone-alt"></i>
      <span>Raw Materials Report</span>
    </a>
  </li>

  <li>
    <a href="customer.php" >
      <i class="glyphicon glyphicon-phone-alt"></i>
      <span>Customer</span>
    </a>
  </li>


  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
       <span>Sales</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales.php">Manage Sales</a> </li>
         <li><a href="add_sale.php">Add Sale</a> </li>
     </ul>
  </li>
  <li>
  <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
       <span>Sales Report</span>
      </a>
      <ul class="nav submenu">
      <li><a href="daily_sales.php">Daily sales</a> </li>
        <li><a href="monthly_sales.php">Monthly sales</a></li>
        <li><a href="test.php">Sales by dates </a></li>
      </ul>
  </li>
</ul>
