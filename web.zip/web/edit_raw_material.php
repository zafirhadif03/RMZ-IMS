<?php
$page_title = 'Edit Raw Material';
require_once('includes/load.php');
page_require_level(2);

// Find the raw material by ID
$material_id = (int)$_GET['id'];
$material = find_by_id('raw_materials', $material_id);
if (!$material) {
  $session->msg("d", "Missing raw material id.");
  redirect('raw_materials.php');
}

// Fetch all suppliers to populate the dropdown
$suppliers = find_all('suppliers');

// If form is submitted for updating the material
if (isset($_POST['update_material'])) {
  $req_fields = array('material-name', 'material-unit', 'material-quantity', 'low-stock', 'supplier-id');
  validate_fields($req_fields);

  if (empty($errors)) {
    $m_name     = remove_junk($db->escape($_POST['material-name']));
    $m_unit     = remove_junk($db->escape($_POST['material-unit']));
    $m_quantity = remove_junk($db->escape($_POST['material-quantity']));
    $low_stock  = remove_junk($db->escape($_POST['low-stock']));
    $supplier_id = remove_junk($db->escape($_POST['supplier-id']));

    // Check if any changes were made
    if ($m_name == $material['name'] &&
        $m_unit == $material['unit'] &&
        $m_quantity == $material['quantity'] &&
        $low_stock == $material['low_stock_threshold'] &&
        $supplier_id == $material['supplier_id']) {
        
        // If no changes were made, display an error message
        $session->msg('d', "Sorry! Failed to edit");
        redirect('edit_raw_material.php?id=' . $material_id, false);
        exit;
    }

    // Update query including supplier_id
    $query  = "UPDATE raw_materials SET ";
    $query .= "name='{$m_name}', unit='{$m_unit}', quantity='{$m_quantity}', low_stock_threshold='{$low_stock}', supplier_id='{$supplier_id}' ";
    $query .= "WHERE id='{$material_id}'";
    
    if ($db->query($query)) {
      $session->msg('s', "Raw material updated successfully.");
      redirect('raw_materials.php', false);
    } else {
      $session->msg('d', 'Failed to update raw material.');
      redirect('edit_raw_material.php?id=' . $material_id, false);
    }
  } else {
    $session->msg("d", $errors);
  }
}
?>

<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
  <br><br>
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-8">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-edit"></span>
          <span>Edit Raw Material</span>
       </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="edit_raw_material.php?id=<?php echo (int)$material['id']; ?>" class="clearfix">
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-th"></i>
              </span>
              <input type="text" class="form-control" name="material-name" value="<?php echo remove_junk($material['name']); ?>" placeholder="Raw Material Name">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-scale"></i>
              </span>
              <input type="text" class="form-control" name="material-unit" value="<?php echo remove_junk($material['unit']); ?>" placeholder="Unit (e.g., kg, g)">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-sort"></i>
              </span>
              <input type="number" class="form-control" name="material-quantity" value="<?php echo remove_junk($material['quantity']); ?>" placeholder="Quantity" step="0.01">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-alert"></i>
              </span>
              <input type="number" class="form-control" name="low-stock" value="<?php echo remove_junk($material['low_stock_threshold']); ?>" placeholder="Low Stock Threshold" step="0.01">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-user"></i>
              </span>
              <select class="form-control" name="supplier-id">
                <option value="">Select Supplier</option>
                <?php foreach ($suppliers as $supplier): ?>
                  <option value="<?php echo (int)$supplier['supplier_id']; ?>" <?php if ($material['supplier_id'] == $supplier['supplier_id']) echo "selected"; ?>>
                    <?php echo remove_junk($supplier['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <button type="submit" name="update_material" class="btn btn-danger">Update Raw Material</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
