<?php
 $errors = array();

 /*--------------------------------------------------------------*/
 /* Function for Remove escapes special
 /* characters in a string for use in an SQL statement
 /*--------------------------------------------------------------*/
function real_escape($str){
  global $con;
  $escape = mysqli_real_escape_string($con,$str);
  return $escape;
}
/*--------------------------------------------------------------*/
/* Function for Remove html characters
/*--------------------------------------------------------------*/
function remove_junk($str){
  $str = nl2br($str);
  $str = htmlspecialchars(strip_tags($str, ENT_QUOTES));
  return $str;
}
/*--------------------------------------------------------------*/
/* Function for Uppercase first character
/*--------------------------------------------------------------*/
function first_character($str){
  $val = str_replace('-'," ",$str);
  $val = ucfirst($val);
  return $val;
}
/*--------------------------------------------------------------*/
/* Function for Checking input fields not empty
/*--------------------------------------------------------------*/
function validate_fields($var) {
  global $errors;
  foreach ($var as $field) {
      $val = remove_junk($_POST[$field]);
      if (isset($val) && $val == '') {
          $errors[] = $field . " can't be blank."; // Append errors to the $errors array
      }
  }
}

/*--------------------------------------------------------------*/
/* Function for Display Session Message
   Ex echo displayt_msg($message);
/*--------------------------------------------------------------*/
function display_msg($msg = '') {
  $output = '';
  if (!empty($msg)) {
      foreach ($msg as $key => $value):
          $output  .= "<div class=\"alert alert-{$key}\">";
          $output  .= "<a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>";

          // Check if $value is an array and join it into a string with line breaks
          if (is_array($value)) {
              $output .= remove_junk(ucfirst(join('<br>', $value)));
          } else {
              $output .= remove_junk(ucfirst($value));
          }

          $output  .= "</div>";
      endforeach;
  }
  return $output;
}


/*--------------------------------------------------------------*/
/* Function for redirect
/*--------------------------------------------------------------*/
function redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
      header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
/*--------------------------------------------------------------*/
/* Function for find out total saleing price, buying price and profit
/*--------------------------------------------------------------*/
function total_price($totals){
   $sum = 0;
   $sub = 0;
   foreach($totals as $total ){
     $sum += $total['total_saleing_price'];
     $sub += $total['total_buying_price'];
     $profit = $sum - $sub;
   }
   return array($sum,$profit);
}
/*--------------------------------------------------------------*/
/* Function for Readable date time
/*--------------------------------------------------------------*/
function read_date($str){
     if($str)
      return date('F j, Y, g:i:s a', strtotime($str));
     else
      return null;
  }
/*--------------------------------------------------------------*/
/* Function for  Readable Make date time
/*--------------------------------------------------------------*/
function make_date(){
  return strftime("%Y-%m-%d %H:%M:%S", time());
}
/*--------------------------------------------------------------*/
/* Function for  Readable date time
/*--------------------------------------------------------------*/
function count_id(){
  static $count = 1;
  return $count++;
}
/*--------------------------------------------------------------*/
/* Function for Creting random string
/*--------------------------------------------------------------*/
function randString($length = 5)
{
  $str='';
  $cha = "0123456789abcdefghijklmnopqrstuvwxyz";

  for($x=0; $x<$length; $x++)
   $str .= $cha[mt_rand(0,strlen($cha))];
  return $str;
}

function get_product_recipes() {
  global $db;
  $query  = "SELECT pr.id, p.name as product_name, rm.name as raw_material_name, pr.quantity ";
  $query .= "FROM product_recipes pr ";
  $query .= "JOIN products p ON pr.product_id = p.id ";
  $query .= "JOIN raw_materials rm ON pr.raw_material_id = rm.id";
  return $db->query($query);
}

function count_all($table) {
  global $db;
  $sql = "SELECT COUNT(*) AS total FROM {$table}";
  $result = $db->query($sql);
  return ($result && $row = $result->fetch_assoc()) ? (int)$row['total'] : 0;
}



?>
