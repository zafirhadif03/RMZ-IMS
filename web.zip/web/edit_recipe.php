<?php
$page_title = 'Edit Recipe';
require_once('includes/load.php');
page_require_level(2);

// Check for product_id in URL
if (!isset($_GET['product_id'])) {
    die("No product ID provided.");
}

$product_id = (int)$_GET['product_id'];

// Open a direct mysqli connection
$mysqli = new mysqli('localhost', 'root', '', 'inventory_system');

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch the existing raw materials for the product
$query = "SELECT r.id AS recipe_id, r.raw_material_id, r.quantity, rm.name AS raw_material_name
          FROM product_recipes r
          JOIN raw_materials rm ON r.raw_material_id = rm.id
          WHERE r.product_id = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

$raw_materials = [];
while ($row = $result->fetch_assoc()) {
    $raw_materials[] = $row;
}

// Fetch all available raw materials for the dropdown
$all_raw_materials_query = "SELECT id, name FROM raw_materials";
$all_raw_materials_result = $mysqli->query($all_raw_materials_query);
$all_raw_materials = [];
while ($row = $all_raw_materials_result->fetch_assoc()) {
    $all_raw_materials[] = $row;
}

// Handle form submission to update the raw materials
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Update existing raw materials
    foreach ($_POST['raw_materials'] as $recipe_id => $data) {
        if (isset($data['delete'])) {
            // Delete raw material
            $delete_query = "DELETE FROM product_recipes WHERE id = ? AND product_id = ?";
            $delete_stmt = $mysqli->prepare($delete_query);
            $delete_stmt->bind_param("ii", $recipe_id, $product_id);
            if (!$delete_stmt->execute()) {
                echo "Error deleting raw material: " . $delete_stmt->error;
            }
        } else {
            // Update the recipe in the database
            $new_quantity = $data['quantity'];
            $raw_material_id = $data['raw_material_id'];

            $update_query = "UPDATE product_recipes SET raw_material_id = ?, quantity = ? WHERE id = ? AND product_id = ?";
            $update_stmt = $mysqli->prepare($update_query);
            $update_stmt->bind_param("idii", $raw_material_id, $new_quantity, $recipe_id, $product_id);

            if (!$update_stmt->execute()) {
                echo "Error updating raw material: " . $update_stmt->error;
            }
        }
    }

    // Add new raw material if provided
    if (isset($_POST['new_raw_material'])) {
        $new_raw_material_id = $_POST['new_raw_material']['raw_material_id'];
        $new_quantity = $_POST['new_raw_material']['quantity'];

        // Insert new raw material into product_recipes
        $insert_query = "INSERT INTO product_recipes (product_id, raw_material_id, quantity) VALUES (?, ?, ?)";
        $insert_stmt = $mysqli->prepare($insert_query);
        $insert_stmt->bind_param("iii", $product_id, $new_raw_material_id, $new_quantity);
        
        if (!$insert_stmt->execute()) {
            echo "Error adding new raw material: " . $insert_stmt->error;
        }
    }

    // Redirect to confirm the changes
    header("Location: convert_to_product.php");
    exit;
}
?>

<?php include_once('layouts/header.php'); ?>

<div class="row">
    <div class="col-md-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-pencil"></span>
                    <span>Edit Recipe</span>
                </strong>
            </div>
            <div class="panel-body">
                <form method="POST" action="edit_recipe.php?product_id=<?php echo $product_id; ?>" class="clearfix" id="recipe-form">
                    <div id="raw-materials-container">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Raw Material</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($raw_materials as $material): ?>
                                    <tr>
                                        <td>
                                            <div class="input-group">
                                                <select name="raw_materials[<?php echo $material['recipe_id']; ?>][raw_material_id]" class="form-control">
                                                    <?php foreach ($all_raw_materials as $raw_material): ?>
                                                        <option value="<?php echo $raw_material['id']; ?>"
                                                            <?php if ($raw_material['id'] == $material['raw_material_id']) echo 'selected'; ?>>
                                                            <?php echo $raw_material['name']; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </td>
                                        <td>
                                            <input type="number" class="form-control" name="raw_materials[<?php echo $material['recipe_id']; ?>][quantity]" value="<?php echo $material['quantity']; ?>" min="0" step="any">
                                        </td>
                                        <td>
                                            <button type="submit" name="raw_materials[<?php echo $material['recipe_id']; ?>][delete]" class="btn btn-danger btn-xs">X</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <button type="button" class="btn btn-primary" id="add-more">Add More Raw Material</button>
                    <button type="submit" class="btn btn-success">Update Recipe</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('add-more').addEventListener('click', function() {
    var container = document.getElementById('raw-materials-container').querySelector('tbody');
    
    var newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td>
            <div class="input-group">
                <select name="new_raw_material[raw_material_id]" class="form-control" required>
                    <option value="">Select Raw Material</option>
                    <?php foreach ($all_raw_materials as $raw_material): ?>
                        <option value="<?php echo $raw_material['id']; ?>"><?php echo $raw_material['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </td>
        <td>
            <input type="number" class="form-control" name="new_raw_material[quantity]" placeholder="Quantity" min="0" step="any" required>
        </td>
        <td>
            <button type="button" class="btn btn-danger btn-xs remove-row">X</button>
        </td>
    `;
    
    container.appendChild(newRow);

    // Add event listener to remove row
    newRow.querySelector('.remove-row').addEventListener('click', function() {
        container.removeChild(newRow);
    });
});

// Add event listeners to existing remove buttons
document.querySelectorAll('.remove-row').forEach(function(button) {
    button.addEventListener('click', function() {
        var row = button.closest('tr');
        row.parentNode.removeChild(row);
    });
});
</script>

<?php include_once('layouts/footer.php'); ?>

<?php $mysqli->close(); ?>
