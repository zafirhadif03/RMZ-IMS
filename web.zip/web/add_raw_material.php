<?php
$page_title = 'Add Raw Material';
require_once('includes/load.php');
page_require_level(2);

// Fetch suppliers to populate the dropdown
$suppliers = find_all('suppliers'); 

// If form is submitted
if (isset($_POST['add_material'])) {
  $req_fields = array('material-name', 'material-unit', 'material-quantity', 'low-stock', 'supplier-id');

  // Check if any required fields are empty
  foreach ($req_fields as $field) {
    if (empty($_POST[$field])) {
      $session->msg("d", "Please fill all the blanks!");
      redirect('add_raw_material.php', false);
      exit;
    }
  }

  $m_name = remove_junk($db->escape($_POST['material-name']));

  // Check for duplicate entry
  $existing_material_query = $db->query("SELECT * FROM raw_materials WHERE name = '{$m_name}' LIMIT 1");
  if($existing_material_query->num_rows > 0) {
    $session->msg("d", "{$m_name} already exists!");
    redirect('add_raw_material.php', false);
    exit;
  }

  // Proceed if no fields are empty and no duplicate found
  if(empty($errors)) {
    $m_unit      = remove_junk($db->escape($_POST['material-unit']));
    $m_quantity  = remove_junk($db->escape($_POST['material-quantity']));
    $low_stock   = remove_junk($db->escape($_POST['low-stock']));
    $supplier_id = remove_junk($db->escape($_POST['supplier-id']));

    // Insert query including the supplier_id
    $query  = "INSERT INTO raw_materials (name, unit, quantity, low_stock_threshold, supplier_id) ";
    $query .= "VALUES ('{$m_name}', '{$m_unit}', '{$m_quantity}', '{$low_stock}', '{$supplier_id}')";
    if ($db->query($query)) {
      $session->msg('s', "Raw material added successfully.");
      redirect('raw_materials.php', false);
    } else {
      $session->msg('d', 'Failed to add raw material.');
    }
  }
}

include_once('layouts/header.php'); 
?>

<div class="row">
  <div class="col-md-12">
  <br><br>
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-8">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th-list"></span>
          <span>Add New Raw Material</span>
       </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="add_raw_material.php" class="clearfix">
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-th"></i>
              </span>
              <input type="text" class="form-control" name="material-name" placeholder="Raw Material Name">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-scale"></i>
              </span>
              <input type="text" class="form-control" name="material-unit" placeholder="Unit (e.g., kg, g)">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-sort"></i>
              </span>
              <input type="number" class="form-control" name="material-quantity" placeholder="Quantity" step="0.01">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-alert"></i>
              </span>
              <input type="number" class="form-control" name="low-stock" placeholder="Low Stock Threshold" step="0.01">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-user"></i>
              </span>
              <select class="form-control" name="supplier-id">
                <option value="">Select Supplier</option>
                <?php foreach ($suppliers as $supplier): ?>
                  <option value="<?php echo (int)$supplier['supplier_id']; ?>">
                    <?php echo remove_junk($supplier['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <button type="submit" name="add_material" class="btn btn-danger">Add Raw Material</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
