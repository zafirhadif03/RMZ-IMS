<?php
  $page_title = 'All Product';
  require_once('includes/load.php');
  // Check what level user has permission to view this page
  page_require_level(2);
  
  // Define the number of results per page
  $results_per_page = 7;

  // Find the total number of products
  $query = "SELECT COUNT(id) AS total FROM products";
  $result = $db->query($query);
  $row = $result->fetch_assoc();
  $total_products = $row['total'];

  // Determine the number of pages needed
  $number_of_pages = ceil($total_products / $results_per_page);

  // Determine the current page
  $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

  // Calculate the starting limit for the query
  $start_from = ($current_page - 1) * $results_per_page;

  
 // Fetch products for the current page
$products = find_by_sql("SELECT products.*, media.file_name AS image, categories.name AS categorie 
                              FROM products 
                              LEFT JOIN media ON products.media_id = media.id 
                              LEFT JOIN categories ON products.categorie_id = categories.id 
                              LIMIT $start_from, $results_per_page");

$query = "SELECT p.id AS product_id, p.name AS product_name, p.categorie_id, p.media_id, p.buy_price, p.sale_price, 
                 r.raw_material_id, r.quantity, rm.name AS raw_material_name, 
                 m.file_name AS media_file_name, m.file_type AS media_file_type
          FROM products p
          JOIN product_recipes r ON p.id = r.product_id
          JOIN raw_materials rm ON r.raw_material_id = rm.id
          LEFT JOIN media m ON p.media_id = m.id
          ORDER BY p.id, r.raw_material_id";



?>

<?php include_once('layouts/header.php'); ?>
  <div class="row">
     <div class="col-md-12">
     <br><br>
       <?php echo display_msg($msg); ?>
     </div>
     
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
        <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Products</span>
         </strong>
         <div class="pull-right">
           <a href="add_product.php" class="btn btn-primary">Add New</a>
         </div>
        </div>
        <div class="panel-body">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th class="text-center" style="width: 50px;">#</th>
                <th> Photo</th>
                <th> Product Title </th>
                <th class="text-center" style="width: 10%;"> Categories </th>
                <th class="text-center" style="width: 10%;"> In-Stock </th>
                <th class="text-center" style="width: 10%;"> Buying Price </th>
                <th class="text-center" style="width: 10%;"> Selling Price </th>
                <th class="text-center" style="width: 10%;"> Added Time </th>
                <th class="text-center" style="width: 100px;"> Actions </th>
              </tr>
            </thead>
           
            <tbody>
  <?php foreach ($products as $product): ?>
  <tr>
    <td class="text-center"><?php echo count_id();?></td>
    <td>
      <?php if($product['media_id'] === '0' || !$product['image']): ?>
        <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="No Image Available">
      <?php else: ?>
        <img class="img-avatar img-circle" src="uploads/products/<?php echo $product['image']; ?>" alt="Product Image">
      <?php endif; ?>
    </td>
    <td> <?php echo remove_junk($product['name']); ?></td>
    <td class="text-center"> <?php echo remove_junk($product['categorie']); ?></td>
    <td class="text-center"> <?php echo remove_junk($product['quantity']); ?></td>
    <td class="text-center"> <?php echo "RM " . remove_junk($product['buy_price']); ?></td>
    <td class="text-center"> <?php echo "RM " . remove_junk($product['sale_price']); ?></td>
    <td class="text-center"> <?php echo read_date($product['date']); ?></td>
    <td class="text-center">
      <div class="btn-group">
        <a href="edit_product.php?id=<?php echo (int)$product['id'];?>" class="btn btn-info btn-xs"  title="Edit" data-toggle="tooltip">
          <span class="glyphicon glyphicon-edit"></span>
        </a>
        <a href="delete_product.php?id=<?php echo (int)$product['id'];?>" class="btn btn-danger btn-xs"  title="Delete" data-toggle="tooltip">
          <span class="glyphicon glyphicon-trash"></span>
        </a>
      </div>
    </td>
  </tr>
  <?php endforeach; ?>
</tbody>

          </table>

          <!-- Pagination Links -->
          <nav aria-label="Page navigation">
            <ul class="pagination">
              <?php for ($page = 1; $page <= $number_of_pages; $page++): ?>
                <li class="<?php if($page == $current_page) echo 'active'; ?>">
                  <a href="product.php?page=<?php echo $page; ?>"><?php echo $page; ?></a>
                </li>
              <?php endfor; ?>
            </ul>
          </nav>

        </div>
      </div>
    </div>
  </div>

<?php include_once('layouts/footer.php'); ?>
