<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="main.css" />
<?php
$page_title = 'Admin Home Page';
require_once('includes/load.php');
// Checkin What level user has permission to view this page
page_require_level(2);

// Fetch data for counters
$c_categorie     = count_by_id('categories');
$c_product       = count_by_id('products');
$c_sale          = count_by_id('sales');
$c_user          = count_by_id('users');
$products_sold   = find_higest_saleing_product('10');
$recent_sales    = find_recent_sale_added('5');

// Fetch total products by category
$products_by_category = count_products_by_category(); // New function to get total products by category

// Function to get total products by category
function count_products_by_category() {
    global $db;
    $sql = "SELECT categories.name AS categorie, COUNT(products.id) AS total_products 
            FROM products 
            JOIN categories ON products.categorie_id = categories.id 
            GROUP BY categories.name";
    return $db->query($sql);
}

include_once('layouts/header.php');
?>
<br><br>

<div class="row">
    <div class="col-md-6">
        <?php echo display_msg($msg); ?>
    </div>
</div>

<div class="row">
    <a href="users.php" style="color:black;">
        <div class="col-md-3">
            <div class="panel panel-box clearfix">
                <div class="panel-icon pull-left bg-secondary1">
                    <i class="glyphicon glyphicon-user"></i>
                </div>
                <div class="panel-value pull-right">
                    <h2 class="margin-top"> <?php echo $c_user['total']; ?> </h2>
                    <p class="text-muted">Users</p>
                </div>
            </div>
        </div>
    </a>

    <a href="categorie.php" style="color:black;">
        <div class="col-md-3">
            <div class="panel panel-box clearfix">
                <div class="panel-icon pull-left bg-red">
                    <i class="glyphicon glyphicon-th-large"></i>
                </div>
                <div class="panel-value pull-right">
                    <h2 class="margin-top"> <?php echo $c_categorie['total']; ?> </h2>
                    <p class="text-muted">Categories</p>
                </div>
            </div>
        </div>
    </a>

    <a href="product.php" style="color:black;">
        <div class="col-md-3">
            <div class="panel panel-box clearfix">
                <div class="panel-icon pull-left bg-blue2">
                    <i class="glyphicon glyphicon-shopping-cart"></i>
                </div>
                <div class="panel-value pull-right">
                    <h2 class="margin-top"> <?php echo $c_product['total']; ?> </h2>
                    <p class="text-muted">Products</p>
                </div>
            </div>
        </div>
    </a>

    <a href="sales.php" style="color:black;">
        <div class="col-md-3">
            <div class="panel panel-box clearfix">
                <div class="panel-icon pull-left bg-green">
                    <i class="glyphicon glyphicon-usd"></i>
                </div>
                <div class="panel-value pull-right">
                    <h2 class="margin-top"> <?php echo $c_sale['total']; ?></h2>
                    <p class="text-muted">Sales</p>
                </div>
            </div>
        </div>
    </a>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-th"></span>
                    <span>Highest Selling Products</span>
                </strong>
            </div>
            <div class="panel-body">
                <canvas id="highestSellingChart" style="width: 100%; height: 400px;"></canvas>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-th"></span>
                    <span>LATEST SALES</span>
                </strong>
            </div>
            <div class="panel-body">
                <canvas id="lineChart" style="width: 100%; height: 400px;"></canvas>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-th"></span>
                    <span>Total Products by Category</span>
                </strong>
            </div>
            <div class="panel-body">
                <canvas id="productsByCategoryChart" style="width: 100%; height: 400px;"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
    // Prepare the data for the "Highest Selling Products" Bar Chart
    const productLabels = [
        <?php foreach ($products_sold as $product_sold): ?>
            "<?php echo remove_junk(first_character($product_sold['name'])); ?>",
        <?php endforeach; ?>
    ];
    const totalSoldData = [
        <?php foreach ($products_sold as $product_sold): ?>
            <?php echo (int)$product_sold['totalSold']; ?>,
        <?php endforeach; ?>
    ];

    const ctxBar = document.getElementById('highestSellingChart').getContext('2d');
    const highestSellingChart = new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: productLabels,
            datasets: [{
                label: 'Total Sold',
                data: totalSoldData,
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Product Name'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Total Sold'
                    }
                }
            }
        }
    });

    // Prepare the data for the "LATEST SALES" Line Chart
    const labels = [
        <?php foreach ($recent_sales as $recent_sale): ?>
            "<?php echo date('M d', strtotime($recent_sale['date'])); ?>",
        <?php endforeach; ?>
    ];
    const data = [
        <?php foreach ($recent_sales as $recent_sale): ?>
            <?php echo $recent_sale['price']; ?>,
        <?php endforeach; ?>
    ];

    const ctxLine = document.getElementById('lineChart').getContext('2d');
    const myLineChart = new Chart(ctxLine, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Total Sales (RM)',
                data: data,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4 // Smooth the curve
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Total Sales (RM)'
                    }
                }
            }
        }
    });

    // Prepare the data for the "Total Products by Category" Doughnut Chart
    const categoryLabels = [
        <?php foreach ($products_by_category as $category): ?>
            "<?php echo remove_junk($category['categorie']); ?>",
        <?php endforeach; ?>
    ];

    const categoryData = [
        <?php foreach ($products_by_category as $category): ?>
            <?php echo (int)$category['total_products']; ?>,
        <?php endforeach; ?>
    ];

    const ctxDoughnut = document.getElementById('productsByCategoryChart').getContext('2d');
    const productsByCategoryChart = new Chart(ctxDoughnut, {
        type: 'doughnut',
        data: {
            labels: categoryLabels,
            datasets: [{
                label: 'Total Products by Category',
                data: categoryData,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(153, 102, 255, 0.5)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                }
            }
        }
    });
</script>

<?php include_once('layouts/footer.php'); ?>
