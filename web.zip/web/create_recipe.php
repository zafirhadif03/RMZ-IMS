<?php
require_once('includes/load.php'); // Include your DB connection

$page_title = 'Create New Recipe';
page_require_level(2); // Check user permission level

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect POST data
    $product_id = (int) $_POST['product_id'];
    $categorie_id = (int) $_POST['categorie_id'];
    $media_id = (int) $_POST['media_id'];
    $buy_price = (float) $_POST['buy_price'];
    $sale_price = (float) $_POST['sale_price'];
    $raw_material_ids = $_POST['raw_material_ids'];
    $quantities = $_POST['quantities'];

    // Check if recipe already exists for the given product_id
    $check_recipe_query = "SELECT * FROM product_recipes WHERE product_id = '$product_id'";
    $check_result = $db->query($check_recipe_query);

    if ($check_result->num_rows > 0) {
        // Recipe already exists, fetch product name
        $product_query = "SELECT name FROM products WHERE id = '$product_id'";
        $product_result = $db->query($product_query);
        $product = $product_result->fetch_assoc();
        
        if ($product) {
            $product_name = $product['name'];
            $error_message = "Recipe for $product_name already exists!";
        } else {
            $error_message = "Recipe already exists for product ID $product_id, but the product name could not be found!";
        }
    } else {
        // Insert or update the product in the products table
        $insert_product_query = "INSERT INTO products (id, buy_price, sale_price, categorie_id, media_id, date) 
                                 VALUES ('$product_id', '$buy_price', '$sale_price', '$categorie_id', '$media_id', NOW()) 
                                 ON DUPLICATE KEY UPDATE buy_price = '$buy_price', sale_price = '$sale_price', categorie_id = '$categorie_id', media_id = '$media_id'";
        $result = $db->query($insert_product_query);

        if (!$result) {
            echo "Error inserting product: " . $db->error;
            exit;
        }

        // Insert each raw material along with additional product details into the product_recipes table
        foreach ($raw_material_ids as $index => $raw_material_id) {
            $quantity = (int) $quantities[$index];
            $insert_recipe_query = "INSERT INTO product_recipes (product_id, raw_material_id, quantity, media_id, categorie_id, buy_price, sale_price) 
                                    VALUES ('$product_id', '$raw_material_id', '$quantity', '$media_id', '$categorie_id', '$buy_price', '$sale_price')";
            $recipe_result = $db->query($insert_recipe_query);

            if (!$recipe_result) {
                echo "Error inserting recipe: " . $db->error;
                exit;
            }
        }

        // Redirect back to Convert to Product page
        $session->msg('s', 'Recipe created successfully!');
        header('Location: convert_to_product.php');
        exit;
    }
}

// Fetch options for dropdowns
$products_result = $db->query("SELECT id, name FROM products");
$categories_result = $db->query("SELECT id, name FROM categories");
$media_result = $db->query("SELECT id, file_name FROM media");
$materials_result = $db->query("SELECT id, name FROM raw_materials");
?>

<?php include_once('layouts/header.php'); ?>
<br>
<br>
<div class="row">
    <div class="col-md-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><span class="glyphicon glyphicon-th"></span> <span>Create New Recipe</span></strong>
            </div>
            <div class="panel-body">
                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>
                <form method="post" action="create_recipe.php">
                    <div class="form-group">
                        <label for="product">Select Product</label>
                        <select name="product_id" class="form-control" required>
                            <option value="">Select Product</option>
                            <?php while($product = $products_result->fetch_assoc()): ?>
                                <option value="<?php echo $product['id']; ?>"><?php echo $product['name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="category">Select Category</label>
                        <select name="categorie_id" class="form-control" required>
                            <option value="">Select Category</option>
                            <?php while($category = $categories_result->fetch_assoc()): ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="media">Select Media (Image)</label>
                        <select name="media_id" class="form-control" required>
                            <option value="">Select Media</option>
                            <?php while($media = $media_result->fetch_assoc()): ?>
                                <option value="<?php echo $media['id']; ?>"><?php echo $media['file_name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="buy_price">Buy Price</label>
                        <input type="number" name="buy_price" class="form-control" step="0.01" required>
                    </div>

                    <div class="form-group">
                        <label for="sale_price">Sale Price</label>
                        <input type="number" name="sale_price" class="form-control" step="0.01" required>
                    </div>

                    <div class="form-group">
                        <label>Raw Materials</label>
                        <div id="raw-materials-container">
                            <div class="row mb-2">
                                <div class="col-md-6">
                                    <select name="raw_material_ids[]" class="form-control" required>
                                        <option value="">Select Raw Material</option>
                                        <?php while($material = $materials_result->fetch_assoc()): ?>
                                            <option value="<?php echo $material['id']; ?>"><?php echo $material['name']; ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-5">
                                    <input type="number" name="quantities[]" class="form-control" placeholder="Quantity" required>
                                </div>
                                <div class="col-md-1 text-center">
                                    <button type="button" class="btn btn-danger remove-row" style="width: 100%;">X</button>
                                </div>
                            </div>
<br>

<button type="button" class="btn btn-primary" id="add-more">Add More Raw Material</button>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Create Recipe</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('add-more').addEventListener('click', function() {
    var container = document.getElementById('raw-materials-container');
    
    var newRow = document.createElement('div');
    newRow.className = 'row mb-2';
    
    newRow.innerHTML = `
        <div class="col-md-6">
            <select name="raw_material_ids[]" class="form-control" required>
                <option value="">Select Raw Material</option>
                <?php 
                $materials_result->data_seek(0); // Reset pointer for each addition
                while($material = $materials_result->fetch_assoc()): ?>
                    <option value="<?php echo $material['id']; ?>"><?php echo $material['name']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-5">
            <input type="number" name="quantities[]" class="form-control" placeholder="Quantity" required>
        </div>
        <div class="col-md-1 text-center">
            <button type="button" class="btn btn-danger remove-row" style="width: 100%;">X</button>
        </div>
    `;
    
    container.insertBefore(newRow, document.getElementById('add-more'));

    newRow.querySelector('.remove-row').addEventListener('click', function() {
        container.removeChild(newRow);
    });
});
</script>

<?php include_once('layouts/footer.php'); ?>
