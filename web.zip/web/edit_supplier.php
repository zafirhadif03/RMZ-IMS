<?php
$page_title = 'Edit Supplier';
require_once('includes/load.php');
// Checking What level user has permission to view this page
page_require_level(2);

// Get the supplier ID from the URL
$supplier_id = (int)$_GET['id'];

// Fetch the supplier by supplier_id (manual query instead of find_by_id)
$query = "SELECT * FROM suppliers WHERE supplier_id='{$supplier_id}' LIMIT 1";
$result = $db->query($query);

// Check if the query was successful
if ($result && $db->num_rows($result) === 1) {
    $supplier = $db->fetch_assoc($result); // Fetch the supplier data
} else {
    $session->msg("d", "Missing supplier id.");
    redirect('suppliers.php');
}

// Update supplier data
if (isset($_POST['update_supplier'])) {
    $req_fields = array('name', 'email', 'phone', 'address');
    validate_fields($req_fields);

    if (empty($errors)) {
        $s_name    = remove_junk($db->escape($_POST['name']));
        $s_email   = remove_junk($db->escape($_POST['email']));
        $s_phone   = remove_junk($db->escape($_POST['phone']));
        $s_address = remove_junk($db->escape($_POST['address']));

        // Update query
        $sql  = "UPDATE suppliers SET ";
        $sql .= "name='{$s_name}', email='{$s_email}', phone='{$s_phone}', address='{$s_address}' ";
        $sql .= "WHERE supplier_id='{$supplier_id}'";
        $result = $db->query($sql);

        if ($result && $db->affected_rows() === 1) {
            $session->msg('s', "Supplier updated.");
            redirect('suppliers.php', false);
        } else {
            $session->msg('d', 'Failed to update the supplier!');
            redirect('edit_supplier.php?id=' . $supplier_id, false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('edit_supplier.php?id=' . $supplier_id, false);
    }
}
?>


<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <br><br>
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-user"></span>
                    <span>Edit Supplier</span>
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="edit_supplier.php?id=<?php echo (int)$supplier['supplier_id']; ?>" class="clearfix">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-user"></i>
                            </span>
                            <input type="text" class="form-control" name="name" placeholder="Supplier Name" value="<?php echo remove_junk($supplier['name']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-envelope"></i>
                            </span>
                            <input type="email" class="form-control" name="email" placeholder="Supplier Email" value="<?php echo remove_junk($supplier['email']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-earphone"></i>
                            </span>
                            <input type="text" class="form-control" name="phone" placeholder="Supplier Phone" value="<?php echo remove_junk($supplier['phone']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-home"></i>
                            </span>
                            <input type="text" class="form-control" name="address" placeholder="Supplier Address" value="<?php echo remove_junk($supplier['address']); ?>">
                        </div>
                    </div>
                    <button type="submit" name="update_supplier" class="btn btn-primary">Update Supplier</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once('layouts/footer.php'); ?>
