<?php
require_once('includes/load.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Add database connection
$mysqli = new mysqli('localhost', 'root', '', 'inventory_system');
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['product_id'])) {
        echo json_encode(['success' => false, 'error' => 'No product ID provided.']);
        exit;
    }

    $product_id = $_POST['product_id'];
    $result = create_product_from_recipe($product_id); // Call the function

    if ($result === true) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $result]); // Display detailed error message
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}

function create_product_from_recipe($product_id) {
    global $mysqli;

    // Fetch the product recipe details
    $query = "SELECT r.raw_material_id, r.quantity FROM product_recipes r WHERE r.product_id = ?";
    $stmt = $mysqli->prepare($query);
    if (!$stmt) {
        return "Error preparing recipe query: " . $mysqli->error;
    }

    $stmt->bind_param("i", $product_id);
    if (!$stmt->execute()) {
        return "Error executing recipe query: " . $stmt->error;
    }

    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        return "No recipe found for Product ID: " . $product_id;
    }

    // Use a valid categorie_id from your `categories` table.
    // Change '1' to a valid category ID from your `categories` table
    $valid_categorie_id = 13;  // Replace with a valid category ID

    // Loop through the recipes and create the product
    while ($row = $result->fetch_assoc()) {
        $raw_material_id = $row['raw_material_id'];
        $quantity = $row['quantity'];

        // Logic to create the product in the products table
        $insert_query = "INSERT INTO products (name, quantity, buy_price, sale_price, categorie_id) VALUES (?, ?, ?, ?, ?)";
        $product_name = "Product for Recipe ID " . $product_id; // Modify as needed
        $buy_price = 10.00; // Modify as needed
        $sale_price = 15.00; // Modify as needed

        $insert_stmt = $mysqli->prepare($insert_query);
        if (!$insert_stmt) {
            return "Error preparing product insert query: " . $mysqli->error;
        }

        $insert_stmt->bind_param("sdddi", $product_name, $quantity, $buy_price, $sale_price, $valid_categorie_id);
        if (!$insert_stmt->execute()) {
            return "Error executing product insert query: " . $insert_stmt->error;
        }

        // Reduce the raw material inventory
        $reduce_result = reduce_inventory($raw_material_id, $quantity);
        if ($reduce_result !== true) {
            return $reduce_result; // Return error from reducing inventory
        }
    }

    return true; // Successfully created product from recipe
}

function reduce_inventory($raw_material_id, $quantity) {
    global $mysqli;

    // Reduce the quantity of the raw material in the inventory
    $update_query = "UPDATE raw_materials SET quantity = quantity - ? WHERE id = ?";
    $update_stmt = $mysqli->prepare($update_query);
    if (!$update_stmt) {
        return "Error preparing inventory update query: " . $mysqli->error;
    }

    $update_stmt->bind_param("di", $quantity, $raw_material_id);
    if (!$update_stmt->execute()) {
        return "Error executing inventory update query: " . $update_stmt->error;
    }

    return true; // Successfully reduced inventory
}

// Close the database connection
$mysqli->close();
?>
