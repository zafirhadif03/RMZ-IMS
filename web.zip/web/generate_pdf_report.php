<?php
// Clear any previously sent output and disable error reporting to prevent output before PDF generation
ob_clean();
error_reporting(0);
ini_set('display_errors', 0);

require_once('C:\xampp\htdocs\web\TCPDF-main\tcpdf.php'); // Adjusted path for TCPDF
require_once('includes/load.php');
page_require_level(2);

// Fetch data for the report
$recent_materials = $db->query("SELECT id, name, quantity, unit, created_at FROM raw_materials ORDER BY created_at DESC LIMIT 10");
$low_stock_materials = $db->query("SELECT id, name, quantity, unit FROM raw_materials WHERE quantity < low_stock_threshold");
$total_used_materials = $db->query("SELECT name, used_quantity, unit FROM raw_materials WHERE used_quantity > 0");
$total_used_sum = $db->query("SELECT SUM(used_quantity) AS total_sum FROM raw_materials WHERE used_quantity > 0")->fetch_assoc();
$total_used_materials = $db->query("SELECT name, used_quantity, unit, DATE_FORMAT(last_used_at, '%Y-%m-%d %H:%i:%s') AS date_used FROM raw_materials WHERE used_quantity > 0");

// Initialize TCPDF
$pdf = new TCPDF();
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Inventory System');
$pdf->SetTitle('Raw Materials Report');

// Remove default header
$pdf->setPrintHeader(false);

// Add a new page
$pdf->AddPage();

// Add the RMZ logo as a header
$logoPath = 'uploads/products/logo RMZ.jpg'; // Adjust the path if necessary
$pdf->Image($logoPath, 10, 10, 30, 15, '', '', 'T', false, 300, '', false, false, 0, false, false, false); // Adjust position and size as needed
$pdf->Ln(20); // Move down after logo

// Define HTML content for the PDF
$html = '<h2>Raw Materials Report</h2><br>';

// Recently Added Raw Materials Section
$html .= '<h3>Recently Added Raw Materials</h3>';
$html .= '<table border="1" cellpadding="5" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="background-color:#f1f1f1; padding: 8px;">Name</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Quantity</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Unit</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Date Added</th>
                </tr>
            </thead>
            <tbody>';
while ($recent = $recent_materials->fetch_assoc()) {
    $html .= '<tr>
                <td style="padding: 8px;">' . htmlspecialchars($recent['name']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($recent['quantity']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($recent['unit']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($recent['created_at']) . '</td>
              </tr>';
}
$html .= '</tbody></table><br><br>';

// Low Stock Alerts Section
$html .= '<h3>Low Stock Alerts</h3>';
$html .= '<table border="1" cellpadding="5" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="background-color:#f1f1f1; padding: 8px;">Name</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Quantity</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Unit</th>
                </tr>
            </thead>
            <tbody>';
while ($low_stock = $low_stock_materials->fetch_assoc()) {
    $html .= '<tr>
                <td style="padding: 8px;">' . htmlspecialchars($low_stock['name']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($low_stock['quantity']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($low_stock['unit']) . '</td>
              </tr>';
}
$html .= '</tbody></table><br><br>';

// Total Raw Materials Used Section
$html .= '<h3>Total Raw Materials Used</h3>';
$html .= '<table border="1" cellpadding="5" style="width:100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="background-color:#f1f1f1; padding: 8px;">Material Name</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Total Used</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Unit</th>
                    <th style="background-color:#f1f1f1; padding: 8px;">Date Used</th>
                </tr>
            </thead>
            <tbody>';
while ($used = $total_used_materials->fetch_assoc()) {
    $html .= '<tr>
                <td style="padding: 8px;">' . htmlspecialchars($used['name']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($used['used_quantity']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($used['unit']) . '</td>
                <td style="padding: 8px;">' . htmlspecialchars($used['date_used']) . '</td>
              </tr>';
}
$html .= '</tbody></table><br><br>';

// Total sum across all materials
$html .= '<p><strong>Total Used Across All Materials: ' . htmlspecialchars($total_used_sum['total_sum']) . ' KG</strong></p>';

// Write the HTML content to the PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Ensure no additional output is sent and output the PDF
ob_end_clean();
$pdf->Output('Raw_Materials_Report.pdf', 'D'); // 'D' for download, 'I' for inline viewing
?>
