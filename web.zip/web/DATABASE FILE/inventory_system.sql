-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2024 at 04:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(13, 'Donut Frozen'),
(9, 'Karipap Frozen'),
(14, 'Keropok Lekor Frozen'),
(16, 'Popia Frozen'),
(15, 'Roti Bom Frozen'),
(10, 'Samosa Frozen');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created_at`) VALUES
(4, 'hj zainal', 'Zainal@gmail.com', '0179522628', 'Shah Alam Selangor', '2024-09-01 15:41:22'),
(5, 'Karim', 'Karim@gmail.com', '0174899364', 'Shah Alam, Selangor', '2024-09-01 15:41:22'),
(7, 'samsul', 'samsul@gmail.com', '0162732536', 'shah alam seksyen 27', '2024-09-03 13:38:54'),
(9, 'Hj Lan', 'Azlan@Gmail.com', '0143529648', 'Batu 3, Selangor', '2024-09-12 10:14:06'),
(10, 'Kevin', 'Kevin01@gmail.com', '0195824593', 'Kajang, Selangor', '2024-09-12 10:14:50');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) UNSIGNED NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `file_name`, `file_type`) VALUES
(3, 'samosa.jpg', 'image/jpeg'),
(4, 'karipap.png', 'image/png'),
(6, 'donut.jpg', 'image/jpeg'),
(7, 'keropok lekor.jpg', 'image/jpeg'),
(8, 'Roti bom.jpg', 'image/jpeg'),
(9, 'popia.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `buy_price` decimal(25,2) DEFAULT NULL,
  `sale_price` decimal(25,2) NOT NULL,
  `categorie_id` int(11) UNSIGNED NOT NULL,
  `media_id` int(11) DEFAULT 0,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `quantity`, `buy_price`, `sale_price`, `categorie_id`, `media_id`, `date`) VALUES
(70, 'Donut ', '18', 9.00, 10.00, 13, 6, '2024-11-07 20:22:30'),
(71, 'Karipap Kentang', '30', 17.00, 20.00, 9, 4, '2024-11-18 15:08:46'),
(72, 'Samosa Kentang', '12', 17.00, 20.00, 10, 3, '2024-10-13 16:30:45'),
(73, 'Roti Bom ', '26', 9.00, 10.00, 15, 8, '2024-11-15 14:33:58'),
(74, 'Popia Sayur', '21', 17.00, 20.00, 16, 9, '2024-10-13 17:04:14'),
(146, 'Karipap Daging', '12', 17.00, 20.00, 9, 4, '2024-11-04 16:27:38'),
(147, 'Keropok Lekor', '17', 17.00, 20.00, 14, 7, '2024-11-15 14:32:08');

-- --------------------------------------------------------

--
-- Table structure for table `product_recipes`
--

CREATE TABLE `product_recipes` (
  `id` int(11) NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `raw_material_id` int(10) UNSIGNED NOT NULL,
  `quantity` decimal(10,0) NOT NULL,
  `media_id` int(11) UNSIGNED DEFAULT NULL,
  `categorie_id` int(11) UNSIGNED NOT NULL,
  `buy_price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) NOT NULL,
  `recipe_quantity` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_recipes`
--

INSERT INTO `product_recipes` (`id`, `product_id`, `raw_material_id`, `quantity`, `media_id`, `categorie_id`, `buy_price`, `sale_price`, `recipe_quantity`) VALUES
(116, 147, 11, 1, 7, 14, 17.00, 20.00, 0),
(117, 147, 12, 1, 7, 14, 17.00, 20.00, 0),
(118, 147, 9, 1, 7, 14, 17.00, 20.00, 0),
(141, 73, 8, 1, 8, 15, 9.00, 10.00, 0),
(142, 73, 12, 1, 8, 15, 9.00, 10.00, 0),
(143, 73, 9, 1, 8, 15, 9.00, 10.00, 0),
(144, 71, 8, 1, 4, 9, 17.00, 20.00, 0),
(145, 71, 1, 1, 4, 9, 17.00, 20.00, 0),
(146, 71, 12, 1, 4, 9, 17.00, 20.00, 0),
(147, 71, 9, 1, 4, 9, 17.00, 20.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `raw_materials`
--

CREATE TABLE `raw_materials` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `low_stock_threshold` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `used_quantity` decimal(10,2) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `raw_materials`
--

INSERT INTO `raw_materials` (`id`, `name`, `unit`, `quantity`, `low_stock_threshold`, `created_at`, `used_quantity`, `supplier_id`, `last_used_at`) VALUES
(1, 'Kentang', 'KG', 9.00, 10.00, '2024-09-17 15:06:51', 8.00, 1, '2024-11-18 15:08:46'),
(8, 'Gula', 'KG', 40.00, 10.00, '2024-09-26 08:21:33', 10.00, 2, '2024-11-18 15:08:46'),
(9, 'Tepung', 'KG', 27.00, 5.00, '2024-09-27 00:58:03', 9.00, 3, '2024-11-18 15:08:46'),
(10, 'Majerine', 'KG', 50.00, 10.00, '2024-10-13 15:57:54', 0.00, 4, '2024-11-15 13:25:45'),
(11, 'Ikan Parang', 'KG', 17.00, 10.00, '2024-10-13 15:58:38', 0.00, 9, '2024-11-15 14:32:08'),
(12, 'Minyak', 'KG', 11.00, 5.00, '2024-10-13 15:59:07', 9.00, 5, '2024-11-18 15:08:46'),
(15, 'Daging', 'KG', 18.00, 15.00, '2024-11-04 08:16:59', 0.00, 10, '2024-11-15 13:25:45');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(25,2) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `qty`, `price`, `date`) VALUES
(22, 71, 2, 40.00, '2024-10-13'),
(23, 72, 1, 20.00, '2024-10-13'),
(24, 70, 5, 50.00, '2024-10-13'),
(26, 71, 4, 80.00, '2024-10-13'),
(34, 73, 1, 12.00, '2024-10-23'),
(35, 73, 1, 12.00, '2024-10-24'),
(36, 73, 1, 12.00, '2024-10-24'),
(37, 71, 1, 20.00, '2024-10-28'),
(38, 70, 1, 10.00, '2024-10-28'),
(39, 71, 1, 20.00, '2024-10-29'),
(40, 73, 1, 12.00, '2024-10-29'),
(41, 73, 1, 12.00, '2024-11-03'),
(42, 73, 1, 12.00, '2024-11-03');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `name`, `email`, `phone`, `address`) VALUES
(1, 'LIKE BEST (M) SDN BHD', 'info@likebest.com.my', '+603-8066 9763', 'Taman Putra Impiana, 47100 Puchong,'),
(2, 'Central Sugars Refinery Sdn. Bhd.', 'enquiry@central-sugars.com.my', '+603 5520 7200', 'Persiaran Teknologi Subang, Batu Tiga, 40000 Shah Alam, Selangor'),
(3, 'Malayan Flour Mills Berhad', 'MalayanFlour@gmail.com', '+603 2170 0999', 'Jalan Ampang, 50450 Kuala Lumpur.'),
(4, 'Adeka Foods (Asia) Sdn Bhd', 'sales@adekafa.com.my', '+607-251 6005', 'Tanjung Langsat Industrial Complex, 81700, Pasir Gudang, Johor.'),
(5, ' GOLDEN PALM OIL INDUSTRIES SDN BHD', 'ALIJAYA2@YAHOO.COM', '+603-9171 3788', ' Bandar Tun Razak, 56000  Kuala Lumpur'),
(9, 'HAI KEE HUNG SDN BHD', 'enquiry@hkh.com.my', '+603-6276 2797', 'Kawasan Perindustrian Taman Ehsan, 52100 Kepong, Kuala Lumpur, Malaysia.'),
(10, 'Frozen Meat Supplier Johor Bahru (JB)', 'sales@raihanahfrozenmeat.com', '+6011-1154 1964', 'Taman Perniagaan Setia, 81100 Johor Bahru, Johor.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `user_level`, `image`, `status`, `last_login`) VALUES
(1, 'Zurzarikha ', 'Admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1, 'gltakonz1.jpg', 1, '2024-11-20 13:08:16'),
(2, 'Zahrul ', 'Special', 'ba36b97a41e7faf742ab09bf88405ac04f99599a', 2, 'no_image.png', 1, '2024-11-03 14:08:02'),
(3, 'Staff', 'User', '12dea96fec20593566ab75692c9949596833adc9', 3, 'no_image.png', 0, '2024-09-27 03:05:17');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Super Admin', 1, 1),
(2, 'Admin', 2, 1),
(3, 'User', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `media_id` (`media_id`);

--
-- Indexes for table `product_recipes`
--
ALTER TABLE `product_recipes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `raw_material_id` (`raw_material_id`);

--
-- Indexes for table `raw_materials`
--
ALTER TABLE `raw_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_level` (`user_level`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `group_level` (`group_level`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `product_recipes`
--
ALTER TABLE `product_recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `raw_materials`
--
ALTER TABLE `raw_materials`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_recipes`
--
ALTER TABLE `product_recipes`
  ADD CONSTRAINT `product_recipes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_recipes_ibfk_2` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_materials` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `SK` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_level`) REFERENCES `user_groups` (`group_level`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
