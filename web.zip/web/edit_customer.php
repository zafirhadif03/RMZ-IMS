<?php
require_once('includes/load.php');
page_require_level(2);

$customer_id = (int)$_GET['id'];
$customer = find_by_id('customers', $customer_id);
if (!$customer) {
    $session->msg("d", "Missing customer id.");
    redirect('customer.php');
}

// Initialize an empty errors array to store any form errors
$errors = [];

if (isset($_POST['update_customer'])) {
    $req_fields = array('name', 'email', 'phone_number', 'address');
    validate_fields($req_fields);

    // Check if there are any errors
    if (empty($errors)) {
        $c_name = $db->escape($_POST['name']);
        $c_email = $db->escape($_POST['email']);
        $c_phone = $db->escape($_POST['phone_number']);
        $c_address = $db->escape($_POST['address']);

        $sql = "UPDATE customers SET";
        $sql .= " name='{$c_name}', email='{$c_email}', phone='{$c_phone}', address='{$c_address}'";
        $sql .= " WHERE id='{$customer_id}'";

        $result = $db->query($sql);

        if (!$result) {
            die('Query Error: ' . $db->con->error);
        }

        if ($db->affected_rows() === 1) {
            $session->msg('s', "Customer updated.");
            redirect('customer.php?id=' . $customer_id, false);
        } else {
            $errors[] = 'Sorry, failed to update the customer!';
        }
    } else {
        // If there are validation errors, they are already in $errors array
        // so we don't need to redirect, just display them below
    }
}
?>

<?php include_once('layouts/header.php'); ?>
<br>
<br>

<div class="row alert-container">
    <div class="col-md-12">
        <?php
        // Display any error messages here
        if (!empty($errors)) {
            echo '<div class="alert alert-danger">';
            foreach ($errors as $error) {
                echo '<p>' . $error . '</p>';
            }
            echo '</div>';
        }
        ?>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-user"></span>
                    <span>Edit Customer</span>
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="edit_customer.php?id=<?php echo (int)$customer_id; ?>" class="clearfix">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-user"></i>
                            </span>
                            <input type="text" class="form-control" name="name" placeholder="Customer Name" value="<?php echo remove_junk($customer['name']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-envelope"></i>
                            </span>
                            <input type="email" class="form-control" name="email" placeholder="Customer Email" value="<?php echo remove_junk($customer['email']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-earphone"></i>
                            </span>
                            <input type="text" class="form-control" name="phone_number" placeholder="Customer Phone" value="<?php echo remove_junk($customer['phone']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-home"></i>
                            </span>
                            <input type="text" class="form-control" name="address" placeholder="Customer Address" value="<?php echo remove_junk($customer['address']); ?>">
                        </div>
                    </div>
                    <button type="submit" name="update_customer" class="btn btn-primary">Update Customer</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once('layouts/footer.php'); ?>
