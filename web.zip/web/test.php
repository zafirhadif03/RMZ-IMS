<?php
$page_title = 'Sales Report';
require_once('includes/load.php');
page_require_level(2);

// Initialize the error message variable
$errors = [];

// Handle form submission
if (isset($_POST['generate_report'])) {
    $start_date = $_POST['start-date'];
    $end_date = $_POST['end-date'];

    // Check if both start and end dates are provided
    if (empty($start_date) || empty($end_date)) {
        $errors[] = "Both start date and end date are required.";
    }

    // Check for any validation errors
    if (!empty($errors)) {
        $session->msg("d", join('<br>', $errors));
        redirect('test.php', false);
    } else {
        $session->msg("s", "Report generated successfully.");
    }
}
?>

<?php include_once('layouts/header.php'); ?>

<div class="row">
    <div class="col-md-12">
        <!-- Display any session messages here -->
        <?php echo display_msg($msg); ?>
    </div>
</div>

<!-- Only show the form if the report has not been submitted -->
<?php if (!isset($_POST['generate_report']) || !empty($errors)): ?>
  <br>
  <br>
<div class="row" id="report-form">
    <div class="col-md-6">
        <div class="panel panel-default">
            <!-- Panel Heading with Blue Bottom Border -->
            <div class="panel-heading" style="border-bottom: 2px solid #3498DB; background-color: #f5f5f5; font-size: 15px; text-transform: uppercase; letter-spacing: .5px; padding: 15px;">
                <strong><span class="glyphicon glyphicon-th"></span> Sales Report</strong>
            </div>
            
            <div class="panel-body">
                <form class="clearfix" method="post" action="test.php">
                    <div class="form-group">
                        <label class="form-label">Date Range</label>
                        <div class="input-group">
                            <input type="text" class="datepicker form-control" name="start-date" placeholder="From" required>
                            <span class="input-group-addon"><i class="glyphicon glyphicon-menu-right"></i></span>
                            <input type="text" class="datepicker form-control" name="end-date" placeholder="To" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="generate_report" class="btn btn-primary">Generate Report</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Report Section -->
<?php
if (isset($_POST['generate_report']) && empty($errors)) {
    echo '<div id="report-section">';
    include(__DIR__ . '/sale_report_process.php');  // Adjust the path if needed
    echo '</div>';
}
?>

<?php include_once('layouts/footer.php'); ?>
