<?php
  require_once('includes/load.php');
  // Check if the user has permission to view this page
  page_require_level(2);

  // Get the customer ID from the URL
  $customer_id = (int)$_GET['id'];

  // Find the customer by ID
  $customer = find_by_id('customers', $customer_id);
  if (!$customer) {
    $session->msg("d", "Missing customer id.");
    redirect('customer.php');
  }

  // Delete the customer
  $delete_id = delete_by_id('customers', $customer_id);

  // Check if the delete operation was successful
  if ($delete_id) {
    $session->msg("s", "Customer deleted.");
  } else {
    $session->msg("d", "Customer deletion failed.");
  }

  // Redirect to the customer page
  redirect('customer.php');
?>
