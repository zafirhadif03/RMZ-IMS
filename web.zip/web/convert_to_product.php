<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$page_title = 'Convert Raw Materials to Product';
require_once('includes/load.php');
page_require_level(2); // Check user permission level

// Open a direct mysqli connection
$mysqli = new mysqli('localhost', 'root', '', 'inventory_system');

// Set timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

// Check connection
if ($mysqli->connect_error) {
    error_log("Database connection failed: " . $mysqli->connect_error);
    die("Database connection failed: " . $mysqli->connect_error); // Exit if the connection fails
}

/// AJAX handler for "Create Product" button
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = (int)$_POST['product_id'];
    $categorie_id = (int)$_POST['categorie_id'];
    $media_id = isset($_POST['media_id']) ? (int)$_POST['media_id'] : null;
    $buy_price = isset($_POST['buy_price']) ? (float)$_POST['buy_price'] : 0.00;
    $sale_price = isset($_POST['sale_price']) ? (float)$_POST['sale_price'] : 0.00;
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;

    // Query to fetch raw materials and quantities required for this product
    $recipe_query = "SELECT raw_material_id, quantity FROM product_recipes WHERE product_id = '$product_id'";
    $recipe_result = $mysqli->query($recipe_query);

    if ($recipe_result && $recipe_result->num_rows > 0) {
        while ($row = $recipe_result->fetch_assoc()) {
            $raw_material_id = $row['raw_material_id'];
            $quantity_needed = $row['quantity'] * $quantity; // Adjust for requested quantity of product

            // Check if enough raw material is available
            $check_quantity_query = "SELECT name, quantity FROM raw_materials WHERE id = $raw_material_id";
            $quantity_result = $mysqli->query($check_quantity_query);

            if ($quantity_result && $quantity_row = $quantity_result->fetch_assoc()) {
                $raw_material_name = $quantity_row['name'];
                $available_quantity = $quantity_row['quantity'];

                // Check if the available quantity is less than the required quantity
                if ($available_quantity < $quantity_needed) {
                    echo json_encode(['success' => false, 'message' => "$raw_material_name is not enough, please restock!"]);
                    exit; // Stop further execution
                }

                // Update raw material quantity: Deduct the used quantity
                $update_query = "UPDATE raw_materials SET used_quantity = used_quantity + $quantity_needed, quantity = quantity - $quantity_needed WHERE id = $raw_material_id";

                if (!$mysqli->query($update_query)) {
                    echo json_encode(['success' => false, 'message' => "Failed to update $raw_material_name due to a system error."]);
                    exit; // Stop further execution
                }
            } else {
                echo json_encode(['success' => false, 'message' => "Error: Unable to fetch data for a required raw material."]);
                exit; // Stop further execution
            }
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'No raw materials found for this product recipe.']);
        exit; // Stop further execution
    }

// This function retrieves the raw materials used for a given product
function get_used_raw_materials($product_id, $mysqli) {
    // Query to fetch raw materials used for the product
    $query = "SELECT rm.id AS raw_material_id, pu.used_quantity
              FROM product_raw_materials pu
              JOIN raw_materials rm ON pu.raw_material_id = rm.id
              WHERE pu.product_id = '$product_id'";
    
    $result = $mysqli->query($query);
    
    // Check if the query was successful and return the data
    if ($result && $result->num_rows > 0) {
        $materials = [];
        while ($row = $result->fetch_assoc()) {
            $materials[] = [
                'raw_material_id' => $row['raw_material_id'],
                'used_quantity' => $row['used_quantity']
            ];
        }
        return $materials;
    } else {
        return []; // Return an empty array if no materials are found
    }
}


// Current date and time in Malaysia timezone
$date = date("Y-m-d H:i:s");

// Fetch raw materials for the product
$query = "SELECT rm.id, rm.name, rm.unit, pr.quantity
          FROM product_recipes pr
          JOIN raw_materials rm ON pr.raw_material_id = rm.id
          WHERE pr.product_id = '$product_id'";
$result = $mysqli->query($query);

if ($result) {
    // Loop through the raw materials and update the last_used_at field
    while ($row = $result->fetch_assoc()) {
        $raw_material_id = $row['id'];
        $last_used_at = $date;  // Current time

        // Update the last_used_at column for each raw material
        $update_query = "UPDATE raw_materials SET last_used_at = '$last_used_at' WHERE id = '$raw_material_id'";
        $mysqli->query($update_query);
    }
} else {
    echo "No raw materials found for this product.";
    exit;
}

// Check if the product already exists in the products table
$check_query = "SELECT id, quantity FROM products WHERE id = '$product_id'";
$check_result = $mysqli->query($check_query);

if ($check_result && $check_result->num_rows > 0) {
    // Product exists, update the quantity (restocking)
    $row = $check_result->fetch_assoc();
    $new_quantity = $row['quantity'] + $quantity;

    // Update the product in the products table
    $query = "UPDATE products SET 
                quantity = '$new_quantity', 
                buy_price = '$buy_price', 
                sale_price = '$sale_price', 
                categorie_id = '$categorie_id', 
                media_id = '$media_id', 
                date = '$date' 
              WHERE id = '$product_id'";
} else {
    // Product does not exist, insert as a new product
    $query = "INSERT INTO products (id, categorie_id, media_id, buy_price, sale_price, quantity, date) 
              VALUES ('$product_id', '$categorie_id', '$media_id', '$buy_price', '$sale_price', '$quantity', '$date')";
}

if (!$mysqli->query($query)) {
    echo json_encode(['success' => false, 'message' => 'Failed to create or update product.', 'error' => $mysqli->error]);
    exit;
}

echo json_encode(['success' => true, 'message' => 'Product created or restocked successfully!']);
exit;


}

// Query to fetch all products and their associated raw materials and media files
$query = "SELECT p.id AS product_id, p.name AS product_name, p.categorie_id, 
                 r.raw_material_id, r.quantity, r.media_id, r.buy_price, r.sale_price, r.quantity AS recipe_quantity,
                 rm.name AS raw_material_name, 
                 m.file_name AS media_file_name, m.file_type AS media_file_type
          FROM products p
          JOIN product_recipes r ON p.id = r.product_id
          JOIN raw_materials rm ON r.raw_material_id = rm.id
          LEFT JOIN media m ON r.media_id = m.id
          ORDER BY p.id, r.raw_material_id";

$result = $mysqli->query($query);
$recipes = [];

// Fetch all recipes and group by product ID
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $product_id = $row['product_id'];
        $recipes[$product_id]['product_name'] = $row['product_name'];
        $recipes[$product_id]['categorie_id'] = $row['categorie_id'];
        $recipes[$product_id]['media_id'] = $row['media_id'] ?? null;
        $recipes[$product_id]['buy_price'] = $row['buy_price'] ?? 0;
        $recipes[$product_id]['sale_price'] = $row['sale_price'] ?? 0;
        $recipes[$product_id]['recipe_quantity'] = $row['recipe_quantity'] ?? 0;

        // Set media details for each product
        if (!isset($recipes[$product_id]['media_file_name'])) {
            $recipes[$product_id]['media_file_name'] = $row['media_file_name'];
            $recipes[$product_id]['media_file_type'] = $row['media_file_type'];
        }

        // Collect multiple raw materials for each product
        if (!isset($recipes[$product_id]['raw_materials'])) {
            $recipes[$product_id]['raw_materials'] = [];
        }

        $recipes[$product_id]['raw_materials'][] = [
            'name' => $row['raw_material_name'],
            'quantity' => $row['quantity']
        ];
    }
}
?>


<?php include_once('layouts/header.php'); ?>
<br><br>

<div class="panel panel-default">
    <div class="panel-heading clearfix">
        <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Recipes</span>
        </strong>
        <a href="create_recipe.php" class="btn btn-primary pull-right" style="margin-top: -7px;">Add New Recipe</a>
    </div>
    
    <div class="panel-body">
        <!-- Recipe cards container -->
        <div class="recipe-cards" style="display: flex; gap: 20px; flex-wrap: wrap;">
        <?php foreach ($recipes as $product_id => $recipe): ?>
            <div class="product-card" 
                 data-product-id="<?php echo $product_id; ?>" 
                 data-categorie-id="<?php echo $recipe['categorie_id'] ?? ''; ?>" 
                 data-media-id="<?php echo $recipe['media_id'] ?? ''; ?>" 
                 data-buy-price="<?php echo $recipe['buy_price'] ?? '0'; ?>"
                 data-sale-price="<?php echo $recipe['sale_price'] ?? '0'; ?>"
                 data-quantity="<?php echo $recipe['recipe_quantity'] ?? '0'; ?>"
                 style="width: 200px; border: 1px solid #ddd; padding: 15px; border-radius: 5px; text-align: center; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); background-color: #f9f9f9;">

                <h3 style="font-size: 1.2em; margin-bottom: 10px;"><?php echo remove_junk($recipe['product_name']); ?></h3>
                
                <!-- Display product image with fixed size -->
                <?php if (!empty($recipe['media_file_name'])): ?>
                    <div style="width: 100%; height: 150px; overflow: hidden; border-radius: 5px; background-color: #eaeaea;">
                        <img src="uploads/products/<?php echo remove_junk($recipe['media_file_name']); ?>" 
                             alt="<?php echo remove_junk($recipe['product_name']); ?>" 
                             style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                <?php else: ?>
                    <div style="width: 100%; height: 150px; background-color: #eaeaea; display: flex; align-items: center; justify-content: center; border-radius: 5px;">
                        <p style="color: #888;">No Image Available</p>
                    </div>
                <?php endif; ?>

                <ul style="list-style-type: none; padding: 0; margin: 10px 0;">
    <?php
    $raw_materials_count = count($recipe['raw_materials']);
    if ($raw_materials_count >= 3): // Ensure at least 3 raw materials
        foreach ($recipe['raw_materials'] as $material): ?>
            <li style="font-size: 0.9em;"><?php echo remove_junk($material['name']); ?>: <?php echo $material['quantity']; ?> KG</li>
        <?php endforeach; 
    else: ?>
        <li class="error" style="color: red; font-size: 0.9em;">Error: This product requires at least 3 raw materials.</li>
    <?php endif; ?>
</ul>





                
                <!-- Vertically stacked buttons with consistent size and spacing -->
                <div style="display: flex; flex-direction: column; gap: 5px; margin-top: 10px;">
                    <button class="btn btn-primary create-product-btn" data-product-id="<?php echo $product_id; ?>" style="width: 100%; font-size: 0.9em; padding: 8px 0;">Create</button>
                    <button class="btn btn-info edit-recipe-btn" data-product-id="<?php echo $product_id; ?>" style="width: 100%; font-size: 0.9em; padding: 8px 0;">Edit</button>
                    <a href="#" class="btn btn-danger delete-recipe-btn" data-product-id="<?php echo $product_id; ?>" style="width: 100%; font-size: 0.9em; padding: 8px 0;">Delete</a>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
</div>



<script>
document.addEventListener('DOMContentLoaded', function() {
    const createButtons = document.querySelectorAll('.create-product-btn');

    createButtons.forEach(button => {
        button.onclick = function() {
            const productId = this.getAttribute('data-product-id');
            const productCard = this.closest('.product-card');
            const categorieId = productCard.getAttribute('data-categorie-id');
            const mediaId = productCard.getAttribute('data-media-id');

            // Parse values from data attributes
            const buyPrice = parseFloat(productCard.getAttribute('data-buy-price')) || 0; // Ensure it's a float
            const salePrice = parseFloat(productCard.getAttribute('data-sale-price')) || 0; // Ensure it's a float
            const quantity = parseInt(productCard.getAttribute('data-quantity')) || 0; // Ensure it's an integer

            console.log("Category ID being sent:", categorieId); // Log the category ID
            console.log("Media ID:", mediaId); // Log the media ID
            console.log("Buy Price:", buyPrice); // Log the buy price
            console.log("Sale Price:", salePrice); // Log the sale price
            console.log("Quantity:", quantity); // Log the quantity

            // Prepare data to send in the request
            const data = `product_id=${productId}&categorie_id=${categorieId}&media_id=${mediaId}&buy_price=${buyPrice}&sale_price=${salePrice}&quantity=${quantity}`;
            console.log("Data to be sent:", data); // Check the complete data string

            // Send an AJAX request to create or restock the product
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'convert_to_product.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            xhr.onload = function () {
                console.log("Response: ", this.responseText); // Logs the raw response text from the server

                try {
                    var response = JSON.parse(this.responseText);
                    console.log("Parsed Response:", response); // Logs the parsed JSON response

                    if (response.success) {
                        alert('Product created or restocked successfully!');
                        window.location.reload();
                    } else {
                        alert('Error: ' + (response.message || 'Unknown error occurred.') + '\n' + response.error);
                    }
                } catch (e) {
                    console.error("Failed to parse JSON: ", e); // Logs JSON parsing errors
                    alert('Error processing response. Please try again.');
                }
            };

            xhr.send(data);
        };
    });

    const editButtons = document.querySelectorAll('.edit-recipe-btn');

    editButtons.forEach(button => {
        button.onclick = function() {
            const productId = this.getAttribute('data-product-id');
            window.location.href = 'edit_recipe.php?product_id=' + productId; // Redirect to edit page
        };
    });

    const deleteButtons = document.querySelectorAll('.delete-recipe-btn');

    deleteButtons.forEach(button => {
        button.onclick = function(e) {
            e.preventDefault(); // Prevent the default link behavior
            const productId = this.getAttribute('data-product-id');

            // Confirmation dialog
            const confirmation = confirm("Are you sure you want to delete the recipe?");
            if (confirmation) {
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'delete_recipe.php', true); // Change to the correct delete script
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (xhr.responseText.includes('success')) {
                        alert('Recipe deleted successfully.');
                        location.reload(); // Reload to see the updated list
                    } else {
                        alert('Error deleting recipe: ' + xhr.responseText);
                    }
                };
                xhr.send('product_id=' + productId);
            }
        };
    });
});
</script>

<?php include_once('layouts/footer.php'); ?>
