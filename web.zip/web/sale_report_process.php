<?php
$page_title = 'Sales Report';
$results = '';
$start_date = '';
$end_date = '';
require_once('includes/load.php');
page_require_level(3);

if (isset($_POST['generate_report'])) {
    $start_date = remove_junk($db->escape($_POST['start-date']));
    $end_date = remove_junk($db->escape($_POST['end-date']));
    
    $results = find_sale_by_dates($start_date, $end_date);
}
?>

<?php if ($results): ?>
  <br>
    <div id="report-content" class="page-break" style="background-color: white; padding: 20px; margin-top: 20px;">
        <div class="sale-head text-center">
            <h1>RMZ Inventory System - Sales Report</h1>
            <strong><?php echo $start_date; ?> TILL DATE <?php echo $end_date; ?></strong> 
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Product Title</th>
                    <th>Buying Price</th>
                    <th>Selling Price</th>
                    <th>Total Qty</th>
                    <th>TOTAL</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $result): ?>
                    <tr>
                        <td><?php echo remove_junk($result['date']); ?></td>
                        <td><?php echo remove_junk(ucfirst($result['name'])); ?></td>
                        <td class="text-right"><?php echo remove_junk($result['buy_price']); ?></td>
                        <td class="text-right"><?php echo remove_junk($result['sale_price']); ?></td>
                        <td class="text-right"><?php echo remove_junk($result['total_sales']); ?></td>
                        <td class="text-right"><?php echo remove_junk($result['total_saleing_price']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="text-right">
                    <td colspan="4"></td>
                    <td><strong>Grand Total</strong></td>
                    <td><strong>RM<?php echo number_format(total_price($results)[0], 2); ?></strong></td>
                </tr>
                <tr class="text-right">
                    <td colspan="4"></td>
                    <td><strong>Profit</strong></td>
                    <td><strong>RM<?php echo number_format(total_price($results)[1], 2); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Add Download PDF Button -->
    <a href="generate_sales_report.php?start=<?php echo $start_date; ?>&end=<?php echo $end_date; ?>" class="btn btn-primary" style="float: right; margin-top: 20px;">Download PDF</a>

<?php else: ?>
    <div class="alert alert-warning">No sales found for the selected date range.</div>
<?php endif; ?>
