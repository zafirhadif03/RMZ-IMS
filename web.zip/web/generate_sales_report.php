<?php
// Start output buffering to clear any previous output
ob_start();
require_once('C:\xampp\htdocs\web\TCPDF-main\tcpdf.php');
require_once('includes/load.php');
page_require_level(3);

$start_date = isset($_GET['start']) ? $_GET['start'] : '';
$end_date = isset($_GET['end']) ? $_GET['end'] : '';
$results = find_sale_by_dates($start_date, $end_date);

if (!$results) {
    die('No sales data found for the selected date range.');
}

// Initialize TCPDF
$pdf = new TCPDF();
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('RMZ Inventory System');
$pdf->SetTitle('Sales Report');

// Remove default header
$pdf->setPrintHeader(false);

// Add a new page
$pdf->AddPage();

// Add the RMZ logo as a header
$logoPath = 'uploads/products/logo RMZ.jpg'; // Adjust the path if necessary
$pdf->Image($logoPath, 10, 10, 30, 15, '', '', 'T', false, 300, '', false, false, 0, false, false, false); // Adjust position and size as needed
$pdf->Ln(10); // Move down after logo

// Add the main title centered
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, 'Sales Report', 0, 1, 'C');

// Add the date range subtitle centered
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(0, 10, "$start_date to $end_date", 0, 1, 'C');
$pdf->Ln(5); // Add some space below the subtitle

// Define HTML content for the sales table
$html = '<table border="1" cellpadding="5">
            <thead>
                <tr>
                    <th><strong>Date</strong></th>
                    <th><strong>Product Title</strong></th>
                    <th><strong>Buying Price</strong></th>
                    <th><strong>Selling Pring</strong></th>
                    <th><strong>Total Qty</strong></th>
                    <th><strong>Total Sale</strong></th>
                </tr>
            </thead>
            <tbody>';

// Populate table rows with data
foreach ($results as $result) {
    $html .= '<tr>
                <td>' . htmlspecialchars($result['date']) . '</td>
                <td>' . htmlspecialchars(ucfirst($result['name'])) . '</td>
                <td style="text-align: right;">' . htmlspecialchars($result['buy_price']) . '</td>
                <td style="text-align: right;">' . htmlspecialchars($result['sale_price']) . '</td>
                <td style="text-align: right;">' . htmlspecialchars($result['total_sales']) . '</td>
                <td style="text-align: right;">' . htmlspecialchars($result['total_saleing_price']) . '</td>
              </tr>';
}

$html .= '</tbody></table><br><br>';

// Grand total and profit in a bordered table
$total_price = total_price($results);
$html .= '<table border="1" cellpadding="5" style="width: 100%; text-align: right;">
            <tr>
                <td colspan="4" style="border: none;"></td>
                <td><strong>Grand Total</strong></td>
                <td><strong>RM' . number_format($total_price[0], 2) . '</strong></td>
            </tr>
            <tr>
                <td colspan="4" style="border: none;"></td>
                <td><strong>Profit</strong></td>
                <td><strong>RM' . number_format($total_price[1], 2) . '</strong></td>
            </tr>
          </table>';

// Write HTML content to PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Clear any buffered output before generating the PDF
ob_end_clean();
$pdf->Output('Sales_Report_' . $start_date . '_to_' . $end_date . '.pdf', 'D'); // 'D' for download
?>
