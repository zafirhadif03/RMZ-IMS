<?php
$page_title = 'Add User';
require_once('includes/load.php');
page_require_level(1);
$groups = find_all('user_groups');

if(isset($_POST['add_user'])) {
  $req_fields = array('full-name', 'username', 'password', 'level');

  // Check if any required fields are empty
  foreach ($req_fields as $field) {
    if (empty($_POST[$field])) {
      $session->msg("d", "Please fill all the blank fields.");
      redirect('add_user.php', false);
      exit;
    }
  }

  $name       = remove_junk($db->escape($_POST['full-name']));
  $username   = remove_junk($db->escape($_POST['username']));
  $password   = remove_junk($db->escape($_POST['password']));
  $user_level = (int)$db->escape($_POST['level']);
  $hashed_password = sha1($password);

  // Check if username already exists
  $existing_user_query = $db->query("SELECT * FROM users WHERE username = '{$username}' LIMIT 1");
  if($existing_user_query->num_rows > 0) {
    $session->msg("d", "{$username} already exists!");
    redirect('add_user.php', false);
    exit;
  }

  // Check if a Super Admin already exists
  if ($user_level === 1) {
    $super_admin_check = $db->query("SELECT * FROM users WHERE user_level = 1 LIMIT 1");
    if($super_admin_check->num_rows > 0) {
      $session->msg("d", "Only one Super Admin account is allowed!");
      redirect('add_user.php', false);
      exit;
    }
  }

  // Check if an Admin already exists
  if ($user_level === 2) {
    $admin_check = $db->query("SELECT * FROM users WHERE user_level = 2 LIMIT 1");
    if($admin_check->num_rows > 0) {
      $session->msg("d", "Only one Admin account is allowed!");
      redirect('add_user.php', false);
      exit;
    }
  }

  // Proceed to create user if no duplicate checks fail
  if(empty($errors)) {
    $query  = "INSERT INTO users (name, username, password, user_level, status) ";
    $query .= "VALUES ('{$name}', '{$username}', '{$hashed_password}', '{$user_level}', '1')";

    if($db->query($query)){
      $session->msg('s', "User account has been created!");
      redirect('add_user.php', false);
    } else {
      $session->msg('d', 'Sorry, failed to create account!');
      redirect('add_user.php', false);
    }
  }
}

include_once('layouts/header.php'); 
?>

<!-- Add some inline CSS for margin adjustment -->
<style>
  .alert-container {
    margin-top: 20px; /* Adjust as needed for spacing below header */
    max-width: 600px; /* Ensures alignment with form width */
    margin-left: auto;
    margin-right: auto;
  }
</style>
<br>
<div class="alert-container">
  <?php echo display_msg($msg); ?> <!-- Display the error message here with padding -->
</div>

<div class="row">
  <br>
  <div class="panel panel-default" style="max-width: 600px; margin: 0 auto;"> <!-- Center the form panel to align with alert -->
    <div class="panel-heading">
      <strong>
        <span class="glyphicon glyphicon-th"></span>
        <span>Add New User</span>
      </strong>
    </div>
    <div class="panel-body">
      <div class="col-md-12">
        <form method="post" action="add_user.php">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" name="full-name" placeholder="Full Name">
          </div>
          <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" name="username" placeholder="Username">
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" name="password" placeholder="Password">
          </div>
          <div class="form-group">
            <label for="level">User Role</label>
            <select class="form-control" name="level">
              <?php foreach ($groups as $group): ?>
                <option value="<?php echo $group['group_level']; ?>"><?php echo ucwords($group['group_name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group clearfix">
            <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
