<?php
$page_title = 'Raw Materials Report';
require_once('includes/load.php');
page_require_level(2); // Assuming level 2 has permission for this report

// Fetch recently added raw materials
$recent_materials = $db->query("SELECT id, name, quantity, unit, created_at FROM raw_materials ORDER BY created_at DESC LIMIT 10");

// Fetch low stock materials (adjust the threshold as necessary)
$low_stock_materials = $db->query("SELECT id, name, quantity, unit FROM raw_materials WHERE quantity < low_stock_threshold");

// Fetch total raw materials used, including last used date
$total_used_materials = $db->query("SELECT name, used_quantity, unit, DATE_FORMAT(last_used_at, '%Y-%m-%d %H:%i:%s') AS date_used FROM raw_materials WHERE used_quantity > 0");

// Fetch total sum of used raw materials
$total_used_sum = $db->query("SELECT SUM(used_quantity) AS total_sum FROM raw_materials WHERE used_quantity > 0")->fetch_assoc();

include_once('layouts/header.php');
?>

<!-- Begin HTML Output -->
<div id="report-content">
  <!-- Recently Added Raw Materials -->
   <br><br>
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-default">
        <div class="panel-heading"><strong>Recently Added Raw Materials</strong></div>
        <div class="panel-body">
          <table class="table table-bordered">
            <thead>
              <tr><th>Name</th><th>Quantity</th><th>Unit</th><th>Date Added</th></tr>
            </thead>
            <tbody>
              <?php while($recent = $recent_materials->fetch_assoc()): ?>
              <tr><td><?php echo $recent['name']; ?></td><td><?php echo $recent['quantity']; ?></td><td><?php echo $recent['unit']; ?></td><td><?php echo $recent['created_at']; ?></td></tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

   <!-- Low Stock Alerts -->
<div class="col-md-6">
  <div class="panel panel-danger">
    <div class="panel-heading"><strong>Low Stock Alerts</strong></div>
    <div class="panel-body">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Unit</th>
          </tr>
        </thead>
        <tbody>
          <?php while($low_stock = $low_stock_materials->fetch_assoc()): ?>
            <tr>
              <td>
                <a href="edit_raw_material.php?id=<?php echo $low_stock['id']; ?>" title="Edit <?php echo $low_stock['name']; ?>">
                  <?php echo $low_stock['name']; ?>
                </a>
              </td>
              <td><?php echo $low_stock['quantity']; ?></td>
              <td><?php echo $low_stock['unit']; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


  <!-- Total Raw Materials Used -->
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-info">
        <div class="panel-heading"><strong>Total Raw Materials Used</strong></div>
        <div class="panel-body">
          <table class="table table-bordered">
            <thead><tr><th>Material Name</th><th>Total Used</th><th>Unit</th><th>Date Used</th></tr></thead>
            <tbody>
              <?php while($used = $total_used_materials->fetch_assoc()): ?>
              <tr><td><?php echo $used['name']; ?></td><td><?php echo $used['used_quantity']; ?></td><td><?php echo $used['unit']; ?></td><td><?php echo $used['date_used']; ?></td></tr>
              <?php endwhile; ?>
            </tbody>
          </table>
          <!-- Button to Download PDF -->
 <a href="generate_pdf_report.php" class="btn btn-primary" style="float: right; margin-top: 20px;">Download PDF</a>

          <p><strong>Total Used Across All Materials: <?php echo number_format($total_used_sum['total_sum'], 2); ?> KG</strong></p>
        </div>
      </div>
    </div>
  </div>
</div>


 <!-- Include html2pdf.js library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
<script>
    document.getElementById('download-pdf').addEventListener('click', function () {
        var element = document.getElementById('report-content');
        var opt = {
            margin:       0.5,
            filename:     'Raw_Materials_Report.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2 },
            jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
        html2pdf().set(opt).from(element).save();
    });
</script>
<?php include_once('layouts/footer.php'); ?>