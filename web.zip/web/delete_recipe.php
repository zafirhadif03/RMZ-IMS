<?php
require_once('includes/load.php'); // Include your DB connection and session handling

header('Content-Type: application/json'); // Set the header for JSON response

// Get the product_id from the POST data
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

if ($product_id === 0) {
    // Return JSON response if product_id is invalid
    echo json_encode(['success' => false, 'message' => 'Invalid product ID.']);
    exit;
}

// Check if the recipe exists in the product_recipes table
$query = "SELECT * FROM product_recipes WHERE product_id = '{$product_id}'";
$result = $db->query($query);

if ($db->num_rows($result) === 0) {
    // If no recipe is found for the product_id
    echo json_encode(['success' => false, 'message' => 'Recipe not found.']);
    exit;
}

// Delete the recipe from the product_recipes table
$delete_query = "DELETE FROM product_recipes WHERE product_id = '{$product_id}'";
$delete_result = $db->query($delete_query);

if ($delete_result && $db->affected_rows() > 0) {
    // Successful deletion
    echo json_encode(['success' => true, 'message' => 'Recipe deleted successfully!']);
} else {
    // Deletion failed or no rows were affected
    echo json_encode(['success' => false, 'message' => 'Error deleting recipe or recipe not found.']);
}

exit;
?>
