<?php
  $page_title = 'Home Page';
  require_once('includes/load.php');
  if (!$session->isUserLoggedIn(true)) { redirect('index.php', false);}

  // Assuming this is where the header starts, you can insert the <link> tag in the 'header.php' file
?>
<?php include_once('layouts/header.php'); ?>
<head>
    <meta charset="UTF-8">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="css/main.css">
</head>
<div class="row">
  <div class="col-md-12">
    <br>
    <?php echo display_msg($msg); ?>
  </div>
 <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
         <h1>Welcome User <hr> RMZ Inventory Management System</h1>
      </div>
    </div>
 </div>
</div>
<?php include_once('layouts/footer.php'); ?>
