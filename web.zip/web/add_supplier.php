<?php
$page_title = 'Add Supplier';
require_once('includes/load.php');
// Check if the user has permission to view this page
page_require_level(2);

// Initialize variables to avoid undefined variable notices
$errors = [];
$msg = '';

// Handle form submission
if (isset($_POST['add_supplier'])) {
    // Define required fields
    $req_fields = array('supplier-name', 'supplier-email', 'supplier-phone', 'supplier-address');
    
    // Validate fields using function from functions.php
    validate_fields($req_fields);

    // Check if there are validation errors
    if (empty($errors)) {
        // Escape and sanitize inputs
        $s_name    = $db->escape($_POST['supplier-name']);
        $s_email   = $db->escape($_POST['supplier-email']);
        $s_phone   = $db->escape($_POST['supplier-phone']);
        $s_address = $db->escape($_POST['supplier-address']);

        // Prepare SQL query to insert supplier data
        $query  = "INSERT INTO suppliers (name, email, phone, address) ";
        $query .= "VALUES ('{$s_name}', '{$s_email}', '{$s_phone}', '{$s_address}')";

        // Execute the query
        try {
            if ($db->query($query)) {
                $session->msg('s', "Supplier added successfully.");
                redirect('suppliers.php', false);
            } else {
                throw new Exception($db->error);
            }
        } catch (Exception $e) {
            $session->msg('d', 'Sorry, failed to add the supplier! Error: ' . $e->getMessage());
            echo "Error on this Query: " . $query;
            echo "<br>MySQL Error: " . $e->getMessage();
            exit();
        }
    } else {
        // If validation errors exist, display a single error message
        $session->msg("d", "Supplier details can't be blank.");
        redirect('add_supplier.php', false);
    }
}
?>

<?php include_once('layouts/header.php'); ?>
<div class="row">
    <div class="col-md-12">
        <br><br>
        <!-- Display session message -->
        <?php echo display_msg($session->msg()); ?>
    </div>
</div>
<div class="row">
    <div class="col-md-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-user"></span>
                    <span>Add New Supplier</span>
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="add_supplier.php" class="clearfix">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-user"></i>
                            </span>
                            <input type="text" class="form-control" name="supplier-name" placeholder="Supplier Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-envelope"></i>
                            </span>
                            <input type="email" class="form-control" name="supplier-email" placeholder="Supplier Email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-earphone"></i>
                            </span>
                            <input type="text" class="form-control" name="supplier-phone" placeholder="Supplier Phone">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="glyphicon glyphicon-home"></i>
                            </span>
                            <input type="text" class="form-control" name="supplier-address" placeholder="Supplier Address">
                        </div>
                    </div>
                    <button type="submit" name="add_supplier" class="btn btn-danger">Add Supplier</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include_once('layouts/footer.php'); ?>
